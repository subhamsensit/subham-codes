#!/usr/bin/python
# -*- coding: utf-8 -*-

import argparse
import subprocess
import json
import re
import os.path
import sys
import time


def execute(cmd):
    '''
    Execute a command and return output if successful
    '''

    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)

    # print(cmd)

    (output, err) = p.communicate()
    if p.returncode:
        print ('execute failed for', cmd)
        print ('exit status', p.returncode)
        print ('stdout', output)
        print ('stderr', err)
        exit(1)
    return output.decode()


def deploy_gateway(
    name,
    region,
    template,
    amiid,
    vpcid,
    isubnetid,
    esubnetid,
    msubnetid,
    externalid,
    initconfig,
    sshkeyname,
    ):

    stackname = name
    if not os.path.exists(initconfig):
        print ('gateway init config file', initconfig, 'does not exists'
               )
        return False
    fd = open(initconfig, 'r')
    initconfigcontent = fd.read()
    command = [
        'aws',
        'cloudformation',
        'create-stack',
        '--region',
        region,
        '--stack-name',
        stackname,
        '--template-body',
        'file://' + template,
        '--parameters',
        'ParameterKey=VpcId,ParameterValue=' + vpcid,
        'ParameterKey=SubnetIntId,ParameterValue=' + isubnetid,
        'ParameterKey=SubnetExtId,ParameterValue=' + esubnetid,
        'ParameterKey=SubnetMgmtId,ParameterValue=' + msubnetid,
        'ParameterKey=ZTAImageAMIId,ParameterValue=' + amiid,
        'ParameterKey=ExternalIPAllocationId,ParameterValue='
           + externalid,
        'ParameterKey=ZTAConfigData,ParameterValue="'
            + initconfigcontent + '"',
        'ParameterKey=KeyName,ParameterValue=' + sshkeyname,
        ]
    output = execute(command)
    while 1:
        command = [
            'aws',
            'cloudformation',
            'describe-stacks',
            '--region',
            region,
            '--stack-name',
            stackname,
            ]
        output = execute(command)
        data = json.loads(output)
        if data['Stacks'][0]['StackStatus'] == 'CREATE_COMPLETE':
            template_outputs = data['Stacks'][0]['Outputs']
            break
        time.sleep(1)

    print (template_outputs)
    return template_outputs


parser = argparse.ArgumentParser(description='Deploy SDP gateway in AWS'
                                 )
parser.add_argument('-n', '--name', required=True,
                    help='Name of the stack')
parser.add_argument('-r', '--region', required=True,
                    help='Name of the region to deploy EIP and gateway in AWS'
                    )
parser.add_argument('-v', '--vpcid', required=True,
                    help='vpc id to deploy gateway')
parser.add_argument('-i', '--internalsubnetid', required=True,
                    help='internal subnet id')
parser.add_argument('-e', '--externalsubnetid', required=True,
                    help='external subnet id')
parser.add_argument('-m', '--mgmtsubnetid', required=True,
                    help='mgmt subnet id')
parser.add_argument('-g', '--gatewaydeploytemplate', required=True,
                    help='Name of the AWS cloud formation template to deploy gateway'
                    )
parser.add_argument('-a', '--pcsamiid', required=True,
                    help='AMI Id of the PCS Image')
parser.add_argument('-d', '--externalallocationid', required=True,
                    help='external eip allocation id')
parser.add_argument('-f', '--gatewayinitconfig', required=True,
                    help='Path of the gateway init config file downloaded from controller'
                    )
parser.add_argument('-s', '--sshkeyname', required=False,
                    default='suresha-us',
                    help='Path of the gateway init config file downloaded from controller'
                    )

args = parser.parse_args()

print ('Deploying gateway...')
gwresult = deploy_gateway(
    args.name,
    args.region,
    args.gatewaydeploytemplate,
    args.pcsamiid,
    args.vpcid,
    args.internalsubnetid,
    args.externalsubnetid,
    args.mgmtsubnetid,
    args.externalallocationid,
    args.gatewayinitconfig,
    args.sshkeyname,
    )
if not gwresult:
    print ('Gateway deployment failed')
    sys.exit(1)

print ('Gateway deployment succeeded')
