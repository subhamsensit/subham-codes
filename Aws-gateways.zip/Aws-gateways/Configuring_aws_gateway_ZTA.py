from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time

driver = webdriver.Firefox()
url= "https://tenant8.navy-blue.pzt.dev.perfsec.com/login/admin"
actions= ActionChains(driver)
def login_to_gateway(url):
   try:
        actions= ActionChains(driver)
        driver.maximize_window()
        driver.get(url)
        driver.set_page_load_timeout(60)


        # clicking on User name form

        username = driver.find_element_by_id("username")
        username.send_keys("admin2")

        password = driver.find_element_by_id("password")

        password.send_keys("sitindia123")

        login_button=driver.find_element_by_id("btnSubmit_6")

        login_button.submit()
        time.sleep(30)
        # Navigating to gateway page
        print("successfully logged in")
        print("Navigating to gateway page")
        driver.get(url+"/admin/#/access/gateways")
       # time.sleep(30)
        driver.set_page_load_timeout(60)
        #driver.find_element_by_id("zero-gateways-create-button")
        element=WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.ID, "zero-gateways-create-button")))
        element.click()
        #gw_button=driver.find_element_by_id("zero-gateways-create-menu-item-0")
        element = WebDriverWait(driver, 40).until(
                EC.presence_of_element_located((By.ID, "zero-gateways-create-menu-item-0")))
        element.click()
        print("clicking on next on create gateway page")
        element = WebDriverWait(driver, 40).until(EC.element_to_be_clickable((By.ID, "zero-gateways-registration-stepper-next-0")))

        element.click()
        time.sleep(10)
        # scroll to view the element
        print("scrolling to find AWS radio button")
        print("clicking on AWS radio button")
        time.sleep(2)
        driver.find_element_by_link_text("Amazon Web Services").click()
        aws_button=WebDriverWait(driver,30).until(EC.element_to_be_clickable(By.XPATH,"//*[@name='gatewayType' and @title=' Amazon Web Services ']/following-sibling::label"))
        aws_button.click()
        time.sleep(2)
        # #element=driver.find_element_by_xpath("//label[normalize-space()='Amazon Web Services']")
        #
        # actions.move_to_element(element)
        # actions.click()
        # actions.perform()
       # driver.execute_script("arguments[0].scrollIntoView();", element)

        #ws_radio_button=WebDriverWait(driver, 40).until(EC.presence_of_element_located((By.ID, "aws-zero-gateways-registration-cloud-gateway-type-radio-button")))


        time.sleep(2)
        print("clicking on Next")
        gateway_next =driver.find_element_by_id("zero-gateways-registration-stepper-next-1")
        driver.execute_script("arguments[0].scrollIntoView();", gateway_next)
        next_button = WebDriverWait(driver, 40).until(EC.presence_of_element_located((By.ID, "zero-gateways-registration-stepper-next-1")))
        next_button.click()
        time.sleep(30)

   except Exception as e:
           print(e)

   finally:
        driver.close()


if __name__ == "__main__":
    login_to_gateway(url)

else:
    print ("Executed when imported")