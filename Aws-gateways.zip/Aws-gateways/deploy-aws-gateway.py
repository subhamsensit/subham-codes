#!/usr/bin/env python3

import argparse
import subprocess
import json
import re
import os.path
import sys
import time


def execute(cmd):
    '''
    Execute a command and return output if successful
    '''
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    #print(cmd)
    (output, err) = p.communicate()
    if p.returncode:
        print('execute failed for', cmd)
        print('exit status', p.returncode)
        print('stdout', output)
        print('stderr', err)
        exit(1)
    return output.decode()


def deploy_gateway(region, template, amiid, internalid, externalid, initconfig,
                   sshkeyname):
    stackname = 'gatewaydeploy'
    if not os.path.exists(initconfig):
        print('gateway init config file', initconfig, 'does not exists')
        return False
    fd = open(initconfig, 'r')
    initconfigcontent = fd.read()
    command = ['aws', 'cloudformation', 'create-stack', '--region', region,
               '--stack-name', stackname, '--template-body',
               "file://"+template,'--parameters',
               "ParameterKey=PCSImageAMIId,ParameterValue="+amiid,
               "ParameterKey=InternalIPAllocationId,ParameterValue="+internalid,
               "ParameterKey=ExternalIPAllocationId,ParameterValue="+externalid,
               "ParameterKey=PCSConfigData,ParameterValue=\""+initconfigcontent+"\"",
               "ParameterKey=KeyName,ParameterValue="+sshkeyname ]
    output = execute(command)
    while (1):
        command = ['aws', 'cloudformation', 'describe-stacks', '--region',
                   region,
                   '--stack-name', stackname]
        output = execute(command)
        data = json.loads(output)
        if data['Stacks'][0]['StackStatus'] == 'CREATE_COMPLETE':
            template_outputs = data['Stacks'][0]['Outputs']
            break
        time.sleep(1)

    print(template_outputs)
    return template_outputs


def deploy_gateway_public_ips(region, template):
    stackname = 'gatewaypublicips'
    if not os.path.exists(template):
        print("Gateway IP template file", template, 'does not exist')
        return False
    command = ['aws', 'cloudformation', 'create-stack', '--region', region,
               '--stack-name', stackname, '--template-body',
               "file://"+template]
    output = execute(command)
    while(1):
        command = ['aws', 'cloudformation', 'describe-stacks', '--region', region,
                   '--stack-name', stackname]
        output = execute(command)
        data = json.loads(output)
        if data['Stacks'][0]['StackStatus'] == 'CREATE_COMPLETE':
            template_outputs = data['Stacks'][0]['Outputs']
            break
        time.sleep(1)

    print(template_outputs)
    result = dict()
    for op in template_outputs:
        if op['OutputKey'] == 'InternalAddress':
            match = re.search('PCS Internal IP address: (\d+\.\d+\.\d+\.\d+) Allocation Id: (.*)',
                              op['OutputValue'])
            result['internalip'] = match.group(1)
            result['internalid'] = match.group(2)
        elif op['OutputKey'] == 'ExternalAddress':
            match = re.search('PCS External IP address: (\d+\.\d+\.\d+\.\d+) Allocation Id: (.*)',
                              op['OutputValue'])
            result['externalip'] = match.group(1)
            result['externalid'] = match.group(2)
    print(result)
    return result




parser = argparse.ArgumentParser(description='Deploy SDP gateway in AWS')
parser.add_argument('-r', '--region',
                     required=True,
                    help='Name of the region to deploy EIP and gateway in AWS')
parser.add_argument('-i', '--gatewayiptemplate',
                     required=True,
                     help='Name of the AWS cloud formation template to deploy EIPs')
parser.add_argument('-g', '--gatewaydeploytemplate',
                     required=True,
                     help='Name of the AWS cloud formation template to deploy gateway')
parser.add_argument('-a', '--pcsamiid',
                     required=True,
                     help='AMI Id of the PCS Image')
parser.add_argument('-f', '--gatewayinitconfig',
                     required=False,
                     default='gateway_pcs.txt',
                     help='Path of the gateway init config file downloaded from controller')
parser.add_argument('-s', '--sshkeyname',
                    required=False,
                    default='sramakrishnan_sdp',
                    help='Path of the gateway init config file downloaded from controller')

args = parser.parse_args()


#
# Create Elastic IPs
print("Generating elastic IP address...")
result = deploy_gateway_public_ips(args.region, args.gatewayiptemplate)
if not result:
    sys.exit(1)

print('Internal IP: ', result['internalip'], 'This IP Address needs to be '
                                             'granted access to the controller'
                                             'mtls and non-mtls endpoints')
print('External IP: ', result['externalip'], 'Use this as a public ip address '
                                             'in controller to create gateway '
                                             'and download gateway config file'
                                             'and store it in the path you provided'
                                             'for option --gatewayinitconfig')

print('Hit enter when you are done with the above two steps...')
input()

print("Deploying gateway...")
gwresult = deploy_gateway(args.region, args.gatewaydeploytemplate, args.pcsamiid,
                          result['internalid'], result['externalid'],
                          args.gatewayinitconfig, args.sshkeyname)
if not gwresult:
    print('Gateway deployment failed')
    sys.exit(1)

print('Gateway deployment succeeded')
