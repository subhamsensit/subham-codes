import json
import requests
import argparse
from DSID_Generate import DSID_Generate

user = "admin"
password = "dana123"

def parse_args():
    p = argparse.ArgumentParser(description='GW Shared Services API')
    p.add_argument('-t','--tenant', help='Tenant FQDN')
    p.add_argument('-g', '--gatewayid', help='Gateway ID')
    p.add_argument('-a', '--action', help='Action to Perform', choices=["enable_debuglogs", "disable_debuglogs", "ping", "ping6", "arp", "traceroute", "traceroute6", "avgrtt", "nslookup", "portprobe", "start_tcpdump", "stop_tcpdump", "upload_file"])
    args = p.parse_args()
    return args

def create_gateway_task():

    args = parse_args()
    tenant = args.tenant
    gateway_id = args.gatewayid
    action = args.action

    host_name = "https://" + tenant + "/"
    dsid_value = ""
    pzt_inst = DSID_Generate()
    dsid_value = pzt_inst.login(host_name[0:-1], user, password)
    print(dsid_value)
    urx = 'https://{}/api/gateways/tasks'.format(tenant)

    headers = {
        "Content-Type": "application/json"
     }

    cookies = {
        "DSID": dsid_value
    }
    task_json = {
        "target": {"id": gateway_id, "type": "appliance"},
        "type": "system.operations.appliance.action.rest",
        "params": {}
    }
    if action == "enable_debuglogs":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/debug-log",
            "data": "{\"enable\":\"True\",\"include_logs\":\"on\",\"max_debug_log_size\":200,\"debug_log_detail_level\":50,\"event_codes\":[\"UNITY::Tasks::Action\", \"Readiness\"], \"process_names\":[\"dsunity\"]}"
        }

    elif action == "disable_debuglogs":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/debug-log",
            "data": "{\"disable\":\"True\",\"include_logs\":\"on\",\"max_debug_log_size\":200,\"debug_log_detail_level\":50,\"event_codes\":[\"UNITY::Tasks::Action\", \"Readiness\"], \"process_names\":[\"dsunity\"]}"
        }

    elif action == "ping":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/commands/ping",
            "data": "{\"target_server\":\"10.64.181.222\", \"interface\":\"int0\",\"command\":\"ping\" }"
        }

    elif action == "ping6":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/commands/ping6",
            "data": "{\"target_server\":\"fe80::a9f8:e345:9592:f716%14\", \"interface\":\"ext0\",\"command\":\"ping6\" }"
        }

    elif action == "arp":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/commands/arp",
            "data": "{\"target_server\":\"10.64.181.222\", \"interface\":\"int0\",\"command\":\"arp\" }"
        }

    elif action == "traceroute":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/commands/traceroute",
            "data": "{\"target_server\":\"www.google.com\", \"interface\":\"int0\",\"command\":\"traceroute\" }"
        }

    elif action == "traceroute6":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/commands/traceroute6",
            "data": "{\"target_server\":\"2a00:1450:400a:804::2004\", \"interface\":\"int0\",\"command\":\"traceroute6\" }"
        }

    elif action == "avgrtt":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/commands/avgrtt",
            "data": "{\"command\":\"avgrtt\" }"
        }

    elif action == "nslookup":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/commands/nslookup",
            "data": "{\"query_type\":\"ANY\", \"query\":\"www.pulsesecure.net\",\"command\":\"nslookup\"  }"
        }

    elif action == "portprobe":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/commands/portprobe",
            "data":"{\"command\":\"portprobe\",\"probe_count\":2,\"probe_timeout\":10,\"protocol\":\"tcp\",\"target_port\":443,\"target_server\":\"test.com\"}"
        }

    elif action == "start_tcpdump":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/tcp-dump",
            "data": "{\"enable\":\"True\",\"interface\":\"mgt0\",\"promiscuous_mode\":\"on\", \"filter\":\"\", \"options\":\"\"}"
        }

    elif action == "stop_tcpdump":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/tcp-dump",
            "data": "{\"disable\":\"True\",\"interface\":\"mgt0\",\"promiscuous_mode\":\"on\", \"filter\":\"\", \"options\":\"\"}"
        }

    elif action == "upload_file":
        task_json['params'] = {
            "method": "POST",
            "path": "api/v1/tasks/upload_file",
            "data": "{\"upload_file_path\":\"https://rajdiag.blob.core.windows.net/test/dumpfile?sv=2020-02-10&ss=bfqt&srt=sco&sp=rwdlacupx&se=2021-02-17T11:49:26Z&st=2021-02-17T03:49:26Z&spr=https&sig=95lujo%2BRHC42cyfaTBI7ZiReZvUjXeCMbVkXbV0Cpmg%3D\",\"filename\":\"/home/runtime/cores/CORE.dsunitytaskd.12085.tgz\",\"type\":\"azure\"}"
        }
    task_status = {"status": "success"}

    j = json.dumps(task_json)

    r = requests.post(urx, j, headers=headers, cookies=cookies)
    print (r.status_code)
    assert r.status_code == 200
    return r.json()

print (create_gateway_task())

