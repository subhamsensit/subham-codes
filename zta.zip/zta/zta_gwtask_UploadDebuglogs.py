import json
import requests


def create_gateway_task():

    dsid_value = '306f909d1808a2bd46611797530ddeeb'
    tenant = 'pine2.pine.pzt.dev.perfsec.com'
    target_location = "https://rajdiag.blob.core.windows.net/test/gwlogtest?sv=2019-12-12&ss=bfqt&srt=sco&sp=rwdlacupx&se=2020-12-11T13:50:21Z&st=2020-12-11T05:50:21Z&spr=https&sig=Wk%2BzPaEWkIb7tjU8cuFioxmWJiP4GDF5cYuu8AjZcBA%3D"
    gateway_id = "1df21b9e843a468e93c0b16beb725b43"

    urx = 'https://{}/api/gateways/tasks'.format(tenant)
    
    headers = {
        "Content-Type": "application/json"
     }

    cookies = {
        "DSID": dsid_value
    }

 
    task_json = {
        "target": {"id": gateway_id, "type": "appliance"},
        "type": "system.operations.appliance.debug.upload_debug_logs",
        "params": {
            "api": "azure",
            "target_upload_file_location": target_location
        }
    }


    task_status = {"status": "success"}

    j = json.dumps(task_json)

    r = requests.post(urx, j, headers=headers, cookies=cookies)

    # r = requests.get(urx, headers=headers, cookies=cookies)
    print (r.status_code)
    assert r.status_code == 200
    return r.json()

print (create_gateway_task())