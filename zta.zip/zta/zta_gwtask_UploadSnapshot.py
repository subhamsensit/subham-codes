import json
import requests


def create_gateway_task():

    dsid_value = '966d3e4d35283f7cd63b54562383880a'
    tenant = 'swan1.swan.pzt.dev.perfsec.com'
    target_location = "https://rajdiag.blob.core.windows.net/test/aartigw-snapshot?sv=2019-12-12&ss=bfqt&srt=sco&sp=rwdlacupx&se=2020-11-10T02:12:38Z&st=2020-11-09T18:12:38Z&spr=https&sig=l0J6E9WG4HWht%2BLCvagoNnBSprzapxeOW%2FRyiyPt7Lg%3D"
    gateway_id = "97f1fa68ca6c4d7ca3ee526b52f8684c"

    urx = 'https://{}/api/gateways/tasks'.format(tenant)
    
    headers = {
        "Content-Type": "application/json"
     }

    cookies = {
        "DSID": dsid_value
    }

 
    task_json = {
        "target": {"id": gateway_id, "type": "appliance"},
        "type": "system.operations.appliance.debug.upload_snapshot",
        "params": {
            "api": "azure",
            "target_upload_file_location": target_location
        }
    }


    task_status = {"status": "success"}

    j = json.dumps(task_json)

    r = requests.post(urx, j, headers=headers, cookies=cookies)

    # r = requests.get(urx, headers=headers, cookies=cookies)
    print (r.status_code)
    assert r.status_code == 200
    return r.json()

print (create_gateway_task())