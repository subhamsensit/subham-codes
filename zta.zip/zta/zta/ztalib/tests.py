try:
    import sys
    import os
    from admin import TenantAdmin
    from time import sleep
    from random import randint
except ImportError as err:
    print(f'Module import failed due to {err}')
    sys.exit(1)

if __name__ == '__main__':
    try:
        #admin = TenantAdmin('tenant8.navy-blue.pzt.dev.perfsec.com','sitindia123','admin')
        admin = TenantAdmin('tenant1.cedar.pzt.dev.perfsec.com','Ivanti@123','admin')
        gw_name="subham-aws"+str(randint(1,99))
        #admin = TenantAdmin('ops1.pulsezta.net','s9MGVmIxMUFMMb6h','admin')
        #admin = TenantAdmin('tenant1.dogwood.pzt.dev.perfsec.com','Psecure@123','admindb')
        #admin = TenantAdmin('tenant2.cedar.pzt.dev.perfsec.com','Lg4KFpe4h4v4PGcW','admin')
        #admin.add_local_auth_server("perf_local_auth")

        #admin.add_user_rule("perf_rule")
        #admin.update_sign_in_policy("User SignIn Policy","perf_local_auth")
        #admin.create_gateway_in_controller("suresha-aws","aws","Mumbai")
        #admin.delete_gateways()
        #admin.add_gateway(admin.create_gateway_in_controller("suresha-aws233","aws","Mumbai"),"aws","Mumbai")
        #admin.add_aws_gateway()

        #admin.add_saml_auth_server("test123")

        #admin.get_auth_server("SDP User Auth")
        #admin.configure_user_policies_saml("test123")
        #admin.update_sign_in_policy("User SignIn Policy","test123")
        #admin.get_gateway_overview("awsgw")
        #admin.verify_gw_logs("awsgw")
        #admin.get_gateway_id("awsgw")

        #admin.create_network_device_policy_rule("perf-network-rule13","perf Network Rule","10.96.161.134","255.255.240.0","allow","high")
        #admin.create_network_device_policy("perf-device13","perf device desc","perf-network-rule25","perf Network Rule","10.96.161.134","255.255.240.0","allow","high")
        #admin.create_registry_device_policy_rule("perf-reg-003", "perf reg", "high", "HKEY_LOCAL_MACHINE", "SAM", "string", "Device", "classic")
        #admin.create_registry_device_policy("perf-reg-policy-002", "perf reg device policy","perf-reg-004", "perf reg", "high", "HKEY_LOCAL_MACHINE", "SAM", "string", "Device", "classic")
        #admin.create_process_device_policy_rule("perf-process-rule-002", "perf process desc", "high", "mac", "securityd_service", "allow", "3dcdea4d4b084667b06398f38dbd8b45")
        #admin.create_process_device_policy("perf-process-006", "perf process","perf-process-rule-002", "perf process desc", "high", "mac", "securityd_service", "allow", "3dcdea4d4b084667b06398f38dbd8b45")
        #admin.create_os_device_policy_rule("perf-os-rule-12", "perf osrule 12", "high", "mac", "Mac Mohave", "Mac Mohave 10.14.1")
        #admin.create_os_device_policy("perf-os-006", "perf os","perf-os-rule-12", "perf osrule 12", "high", "mac", "Mac Mohave", "Mac Mohave 10.14.1")
        #admin.create_file_device_policy_rule("perf-file-112", "perf file desc", "high", "mac", "perf.txt", "allow","3dcdea4d4b084667b06398f38dbd8b45")
        #admin.create_file_device_policy("perf-dev-file-112", "perf process","perf-file-113", "perf file desc", "high", "mac", "perf.txt", "allow","3dcdea4d4b084667b06398f38dbd8b45")
        #admin.get_device_policy_rules()

        #staging
        #admin.create_aws_public_ips("suresha-production-ip-5", "us-west-1", "AWS-GW-Deployment/gatewaypublicips.json", "MC_pzt-infra-staging-staging_staging_uksouth", "aks-agentpool-14770049-nsg")
        #admin.add_aws_gateway("awsgw", "aws", 97, "54.151.106.211", "8.8.8.9", "8.8.8.8", "pulsesecure.net")

       # #west -us  Subham
       # admin.create_aws_public_ips("subham-naji-ip-8", "us-west-1", "AWS-GW-Deployment/gatewaypublicips.json", "MC_pzt-infra-sreeblzta-dev_sreeblzta_westus", "aks-agentpool-92194893-nsg")
       # print("calling ad aws gateway function and gateway name to be configured is %s "%gw_name)
        admin.add_aws_gateway(gw_name, "aws", 97, "54.219.249.81", "8.8.8.8", "8.8.4.4", "pulsesecure.net")

        #2nd west -us
        #admin.create_aws_public_ips("suresha-perf-ip-aws-002", "us-west-1", "AWS-GW-Deployment/gatewaypublicips.json", "MC_pzt-infra-sreeblzta-dev_sreeblzta_westus", "aks-agentpool-92194893-nsg")
        #admin.add_aws_gateway("aws01", "aws", 104, "13.52.127.213", "8.8.8.9", "8.8.8.8", "pulsesecure.net")

        # west -us deepak
        #admin.create_aws_public_ips("suresha-t1-dogwood-demo-ip-06", "us-west-1", "AWS-GW-Deployment/gatewaypublicips.json", "MC_pzt-infra-deepakkzta-dev_deepakkzta_westus", "aks-agentpool-57782232-nsg")
        #admin.add_aws_gateway("awsgw", "aws", 97, "54.177.89.201", "8.8.8.9", "8.8.8.8", "pulsesecure.net")
        
        #2nd west -us for harsh
        #admin.create_aws_public_ips("suresha-perf-ip-aws-002", "us-west-1", "AWS-GW-Deployment/gatewaypublicips.json", "mc_pzt-infra-hsingh01-dev_hsingh01_westus", "aks-agentpool-37931096-nsg")
        #admin.add_aws_gateway("aws02", "aws", 97, "184.169.254.1", "8.8.8.9", "8.8.8.8", "pulsesecure.net")

        #Mumbai
        #admin.create_aws_public_ips("suresha-perf-ip-aws-01", "ap-south-1", "AWS-GW-Deployment/gatewaypublicips.json", "MC_pzt-infra-sreeblzta-dev_sreeblzta_westus", "aks-agentpool-92194893-nsg")
        #admin.add_aws_gateway("aws1", "aws", 104, "35.154.162.204", "8.8.8.9", "8.8.8.8", "pulsesecure.net")


        #admin.add_users_to_local_auth_server('SDP User Auth',2)
        #admin.add_users_to_local_auth_server('SDP User Auth','user3')
        '''
        Step2: 
        Create 3 user rules:
        '''
        '''
        i) 4D Secure access -> Users -> User Rules and groups -> Add user Rule
        RuleName: ‘ruleforuser1’
        AttributeType: Username
        Expression: Matching
        User: user1
        '''
        #admin.add_user_rule('ruleforuser1','username','user1')




        '''
        ii) 4D Secure access -> Users -> User Rules and groups -> Add user Rule
        RuleName: ‘ruleforuser2’
        AttributeType: Username
        Expression: Matching
        User: user2
        '''
       # admin.add_user_rule('ruleforuser2','username','user2')




        '''
        iii)4D Secure access -> Users -> User Rules and groups -> Add user Rule
        RuleName: ‘ruleforuser3’
        AttributeType: Username
        Expression: Matching
        User: user3
        '''
        #admin.add_user_rule('ruleforuser3','username','user3')



        '''
        Step3:
        Create 3 user groups:
        '''
        '''
        i) 4D Secure access-> Users -> User Rules and groups -> User groups -> Add User Group 
        User group name: groupforuser1
        Authentication policy: User signin policy
        Description: group for user1
        User Rules: ruleforuser1
        '''
       # admin.add_user_rule_group('User SignIn Policy','ruleforuser1','groupforuser1')



        '''
        ii) 4D Secure access-> Users -> User Rules and groups -> User groups -> Add User Group 
        User group name: groupforuser2
        Authentication policy: User signin policy
        Description: group for user2
        User Rules: ruleforuser2
        '''
        #admin.add_user_rule_group('User SignIn Policy','ruleforuser2','groupforuser2')




        '''
        iii) 4D Secure access-> Users -> User Rules and groups -> User groups -> Add User Group 
        User group name: groupforuser3
        Authentication policy: User signin policy
        Description: group for user3
        User Rules: ruleforuser3
        '''
       # admin.add_user_rule_group('User SignIn Policy','ruleforuser3','groupforuser3')




        #admin.create_resource_group('Demo')



        '''
        Step4:
        Add two applications:
        '''
        '''
        I) 4D Secure Access -> Applications -> Applications -> ADD
        Application name: OnPremResource
        Application Type: fqdn
        Application details: https://sdpserver.pulsesecure.net
        Application icon: Bamboo.svg
        Description: On prem resource
        Access type: application
        '''
        #admin.create_resource('Demo','OnPremResource','fqdn','https://sdpserver.pulsesecure.net','application')
        



        '''
        ii) 4D Secure Access -> Applications -> Applications -> ADD
        Application name: CloudResouce
        Application Type: fqdn
        Application details: https://cloudres.unitydev.io
        Application icon: Bamboo.svg
        Description: Cloud resource
        Access type: application
        '''
        #admin.create_resource('Demo','CloudResouce','fqdn','https://cloudres.unitydev.io','application')
        


        '''
        Step5:
        Secure Policies
        '''
        '''
        I) 4D Secure Access Policies -> Add Policy
        Application type: Single
        Application: OnPremResource
        Device policy: SymantecAVMedium
        UserGroup: groupforuser1
        Gateway: esxgw (use any existing)
        '''
        #admin.create_secure_access_policy('groupforuser1','OnPremResource','esxgw')


        '''
        Ii) 4D Secure Access Policies -> Add Policy
        Application type: Single
        Application: OnPremResource
        Device policy: SymantecAV
        UserGroup: groupforuser2
        Gateway: awsgw (use any existing)
        '''
        #admin.create_secure_access_policy('groupforuser2','OnPremResource','awsgw')



        '''
        iii) 4D Secure Access Policies -> Add Policy
        Application type: Single
        Application: CloudResource
        Device policy: SymantecAVLow
        UserGroup: groupforuser3
        Gateway: azuregw (use any existing)
        '''
        #admin.create_secure_access_policy('groupforuser1','CloudResouce','azuregw')

        
        del admin
    except Exception:
        del admin
    
    
    

    