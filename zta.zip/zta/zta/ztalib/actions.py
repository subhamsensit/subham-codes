__author__ = 'Vamsi Porala'
__email__ = 'vporala@pulsesecure.net'

try:
    import sys
    import os
    import logging
    from traceback import format_exc
    import json
    import yaml
    from time import sleep
    from datetime import date
    from ztalib.utils import ConfigParser, Generators
except ImportError as err:
    print(f'Module import failed in {__name__} due to {err}')
    sys.exit(1)


class PreTest(object):
    """
    This class contains the methods to be exercised before
    starting the test
    """

    def __init__(self):
        self.test_data = None
        self.logger = None

    def initial_checks(self, config_file):
        result = True
        try:
            # Parse the yaml file
            parser = ConfigParser()
            self.test_data = parser.parse_config(config_file)
            if self.test_data is None:
                raise Exception

            # Initialize the logger
            generator = Generators()
            log_location = generator.generate_log_path(self.test_data['zta']['tenants']['domain'])
            if log_location is None:
                raise Exception
            self.logger = generator.generate_logger(log_location)
            if self.logger is None:
                raise Exception
            self.logger.info("Test Inputs file is parsed successfully")
            self.logger.info("Initialized the Logger successfully")
        except:
            print(format_exc())
            result = False
        finally:
            return result

    def fetch_tenant_admin_creds(self, domain, tenant, creds_folder="/root/zta/perftest/creds/"):
        result = None
        try:
            self.logger.info("Fetching the Tenant Admin Credentials")
            cred_file = f'{creds_folder}{domain}'
            print(cred_file)
            if os.path.isfile(cred_file) is not True:
                self.logger.error("Tenant Admin Credential File is not Found")
                raise Exception
            with open(cred_file, 'r') as fd:
                content = fd.readlines()
                fd.close()
            for line in content:
                admin_info = json.loads(line)
                if admin_info['name'] == f'{tenant}.{domain}':
                    result = {"username": admin_info["username"],
                              "password": admin_info["password"]}
                    self.logger.info("Fetched Tenant Admin credentials successfully")
        except:
            self.logger.error("Failed to fetch the Tenant Admin Credentials")
            self.logger.error(format_exc())
        finally:
            if result is None:
                self.logger.error("Unable to find requested tenant details")
            return result

