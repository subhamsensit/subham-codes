
import argparse
import subprocess
import json
import re
import os
import sys
import time

def __init__(self):
        pass

def execute(cmd):
    '''
    Execute a command and return output if successful
    '''
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    #print(cmd)
    (output, err) = p.communicate()
    if p.returncode:
        print('execute failed for', cmd)
        print('exit status', p.returncode)
        print('stdout', output)
        print('stderr', err)
        exit(1)
    return output.decode()

def deploy_gateway_public_ips(name, region, template):
    stackname = name
    print(stackname)
    print(region)
    print(template)
    if not os.path.exists(template):
        print("Gateway IP template file", template, 'does not exist')
        return False
    command = ['aws', 'cloudformation', 'create-stack', '--region', region,
               '--stack-name', stackname, '--template-body',
               "file://"+template]
    output = execute(command)
    while(1):
        command = ['aws', 'cloudformation', 'describe-stacks', '--region', region,
                   '--stack-name', stackname]
        output = execute(command)
        data = json.loads(output)
        if data['Stacks'][0]['StackStatus'] == 'CREATE_COMPLETE':
            template_outputs = data['Stacks'][0]['Outputs']
            break
        time.sleep(1)

    print("Inside1::::::",template_outputs)
    result = dict()
    for op in template_outputs:
        if op['OutputKey'] == 'InternalAddress':
            match = re.search('PCS Internal IP address: (\d+\.\d+\.\d+\.\d+) Allocation Id: (.*)',
                              op['OutputValue'])
            result['internalip'] = match.group(1)
            result['internalid'] = match.group(2)
        elif op['OutputKey'] == 'ExternalAddress':
            match = re.search('PCS External IP address: (\d+\.\d+\.\d+\.\d+) Allocation Id: (.*)',
                              op['OutputValue'])
            result['externalip'] = match.group(1)
            result['externalid'] = match.group(2)
    print("Inside2::::::",result)
    return result


def update_az_network_security(azureresourcegroup, azurenwsecgroup, internalip):
    dn = os.path.dirname(os.path.realpath(__file__))
    # update this internal ip into azure
    command = [dn+'/awsupdateAzNwSecurityRules', azureresourcegroup,
                       azurenwsecgroup, internalip]
    output = execute(command)
    print(output)
    return True                     
            

# parser = argparse.ArgumentParser(description='Create IP addresses in AWS')
# parser.add_argument('-n', '--name',
#                      required=True,
#                     help='Name of the stack')
# parser.add_argument('-r', '--region',
#                      required=True,
#                     help='Name of the region to deploy EIP and gateway in AWS')
# parser.add_argument('-i', '--gatewayiptemplate',
#                      required=True,
#                      help='Name of the AWS cloud formation template to deploy EIPs')
# parser.add_argument('-a', '--azureresourcegroup',
#                     required=True,
#                     help='azure resource group to update the sec group')
# parser.add_argument('-s', '--azurenwsecgroup',
#                     required=True,
#                     help='network security group')
# args = parser.parse_args()


#
# Create Elastic IPs
# print("Generating elastic IP address...")
# result = deploy_gateway_public_ips(args.name, args.region, args.gatewayiptemplate)
# #result = deploy_gateway_public_ips("suresha-ip", "ap-south-1", "gatewaypublicips.json")
# if not result:
#     sys.exit(1)

# print('internal:' + result['internalip'] + ':' + result['internalid'])
# print('external:' + result['externalip'] + ':' + result['externalid'])

# dn = os.path.dirname(os.path.realpath(__file__))

# # update this internal ip into azure
# command = [dn+'/updateAzNwSecurityRules', args.azureresourcegroup,
#            args.azurenwsecgroup, result['internalip'] ]
# output = execute(command)
# print(output)


