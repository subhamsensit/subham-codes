__author__ = 'Vamsi Porala'
__email__ = 'vporala@pulsesecure.net'

try:
    import sys
    import os
    from httpx import AsyncClient
    from requests import Session
    from requests.exceptions import RequestException
    from requests import get
    from traceback import format_exc
    from random import choice
    import re
    import json
    import xml.etree.ElementTree as ET
    from urllib3 import disable_warnings
    from urllib3.exceptions import InsecureRequestWarning
    from kubernetes import client, config
    from urllib.parse import urlparse
    from time import sleep
    from email import message_from_string
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from awsgenerateipaddresses import *
    import smtplib
    import base64
    import random
    import subprocess
    import argparse
    
except ImportError as err:
    print(f'Module import failed in {__name__} due to {err}')
    sys.exit(1)

# SMTP account to send email
SMTP_HOST = "smtp.mailgun.org"
SMTP_USER = "api-tests@unitydev.io"
SMTP_PASSWORD = "rAezuXczU8zdh24vRzippCbLDNrGwWuG"
SMTP_PORT = 587

MAILGUN_API_KEY = "key-bbd675aa2770c641f2ca14732675fe13"
MAILGUN_API_URL = f"https://api:{MAILGUN_API_KEY}@api.mailgun.net"


class PulseMail(object):
    """
    A wrapper around a very specific PulseSecure test email account.

    This class facilitates retrieving messages sent to a specific mailbox for
    the PulseSecure test email account. Only messages sent to the specific
    mailbox can be retrieved.

    NOTE: adapted for End-to-End testing from:
    https://dev.pulsesecure.net/stash/projects/PWS/repos/api-tests/browse/plugins/emails.py#64
    """

    def __init__(self, to_addr):
        """
        Args:
            to_addr (str): The email address you want to get mail for. This must
                be a variant of api-test+{id}@example.com
        """
        username, domain = to_addr.split("@", 1)
        self._to_addr = to_addr
        self._domain = domain
        self._api_url = MAILGUN_API_URL
        u = urlparse(MAILGUN_API_URL)
        self._username = u.username
        self._password = u.password

    def messages(self, retry=300):

        """
        Returns an iterator containing messages for a specific email address.

        Args:
            retry (int): Mailgun can take a few seconds to register new messages
                so if there are no messages, try again up to `retry` times.
        """

        tries = retry + 1
        events = []

        while tries > 0:
            tries -= 1
            r = get(
                "%s/v3/%s/events" % (self._api_url, self._domain),
                params={
                    "limit": 25,
                    "event": "stored",
                    # FIXME According to https://documentation.mailgun.com/api-events.html#filter-field
                    # you should be able to filter by `to` or `recipient`. `to` only seems
                    # to work if you match the field exactly (name + email). `recipient` doesn't
                    # seem to work at all. So instead of using these filters, we have to get
                    # all recent emails and filter them our side. Maybe one day these APIs
                    # will work correctly. A support issue has been opened with mailgun.
                    # 'to': self._to_addr,
                    # 'recipient': self._to_addr,
                    "ascending": "no",
                },
            )

            if r.status_code == 401:
                raise Exception("Could not authenticate with mailgun.")

            assert r.status_code == 200

            items = r.json()["items"]
            if items:
                # FIXME Filter by email since `recipient` filter above does not work
                events.extend(
                    item
                    for item in items
                    if self._to_addr in item["message"]["recipients"]
                )
                if events:
                    break
            else:
                sleep(1)

        messages = []
        for event in events:
            url = event["storage"]["url"]
            # `Accept: message/rfc2822` still returns JSON with the mime
            # message in a `body-mime` key.
            response = get(
                url,
                headers={"Accept": "message/rfc2822"},
                auth=(self._username, self._password),
            )

            assert response.status_code == 200, response.text

            """
            NOTE: the type is Message, not always email.message.Message because 
            ... interpreter
            """

            response_body = message_from_string(response.json()["body-mime"])
            email_payload = base64.b64decode(response_body.get_payload())
            messages.append(
                {
                    "html_body": email_payload.decode(),
                    "subject": response_body["Subject"],
                    "sender": response_body["From"],
                    "recepient": response_body["To"],
                }
            )

        skip = '''
        if messages:
            print("%d messages for %s." % (len(messages), self._to_addr))
        else:
            print("No messages for %s." % self._to_addr)
        '''
        return messages


class SuperAdmin(Session):
    """
        This class contains the actions of a Pule Zero Trust administrator
        who accesses and manages the tenant consoles
    """
    # Constructor
    def __init__(self, kube_config_file):
        super(self.__class__, self).__init__()
        disable_warnings(InsecureRequestWarning)
        config.load_kube_config(kube_config_file)
        self.api = client.ApiextensionsApi()
        self.kubectl = client.CoreV1Api()
        self.headers['Content-Type'] = 'application/json'

    def create_tenant(self, tenant_name, tenant_svc_fqdn, admin_name, admin_email):
        result = None
        try:
            tenant_data = {
                "sub_domain": tenant_name,
                "user": {"full_name": admin_name, "email": admin_email}
            }
            resp = self.post(url=f'https://{tenant_svc_fqdn}/api/tenants',
                             json=tenant_data,
                             verify=False)
            if resp.status_code != 200:
                print('Failed to create the tenant')
                raise Exception
            result = resp.json()
        except:
            print(format_exc())
        finally:
            return result

    def get_tenants(self, tenant_svc_fqdn):
        try:
            resp = self.get(url=f'https://{tenant_svc_fqdn}/api/tenants',
                            verify=False)
            print(resp.status_code, resp.json())
        except:
            return None

    def verify_tenant(self, tenant_id, name_space='default'):
        try:
            result = self.kubectl.list_namespaced_pod(namespace=name_space)
            for pod in result.items:
                if tenant_id in pod.metadata.name:
                    return True
            return False
        except:
            return False

    def fetch_tenants(self, name_space='default'):
        try:
            print(self.api.get_api_group())
            tenant_list = []
            result = self.kubectl.list_namespaced_pod(namespace=name_space)
            for pod in result.items:
                if 'tenant-aaa' in pod.metadata.name:
                    tenant_list.append(pod.metadata.name)
                    # print(self.kubectl.read_namespaced_pod(name=pod.metadata.name, namespace=name_space))
            print(tenant_list)
            return tenant_list
        except:
            return None

    @staticmethod
    def fetch_tenant_credentials(admin_email, tenant):
        result = None
        try:
            admin_password = None
            messages = PulseMail(admin_email).messages(retry=120)
            # print(messages)
            if messages:
                for message in messages:
                    if 'html_body' in message.keys():
                        if tenant in message['html_body'] and \
                                'username">admin' in message['html_body']:
                            email_body = message['html_body']
                            match = re.search(r'password\">([0-9A-Za-z]+)</span>', email_body)
                            if match is not None:
                                admin_password = match.group(1)
                                result = {'username': 'admin',
                                          'password': admin_password}
                                break
                            else:
                                raise Exception
        except:
            print(format_exc())
        finally:
            return result

    @staticmethod
    def send_email(tenant_data, target_email):
        result = True
        try:
            msg = MIMEMultipart()
            msg_body = f"""
                <html>
                <head></head>
                <body style="font-size: 1.2em;font-family: arial;color: #333;background-color:#fff;">
                <div style="width:100%;background-color: #fff;border-bottom: 2px solid #d1d1d1">
                <img id="logo" style="height:60px"
                src="https://s3.amazonaws.com/assets-pzt/ps-logo-black.svg">
                <br />
                </div>
                            <!--BODY-->
                          <table style="background-color:#fff; border-bottom: 3px solid #e2e2e2;" class="container">
                              <!--greep top bar-->
                                <tr style="background-color: #2850FF;height: 40px;">
                                  <td style="background-image: url('https://ui.unitydev.io/admin/email-images/mesh_banner.png'); background-repeat:repeat-x;"></td>
                                </tr>
                              <!--end greep top bar-->
                                <tr>
                                  <td>
                                <!--white intro-->
                                    <table class="row">
                                      <tr>
                                        <td class="wrapper last">
            
                                          <table class="twelve columns">
                                            <tr>
                                              <td style="padding: 30px 50px 0;">
                                                <p style="color: #525252;font-size:15px;">Hello PZTA Administrator,</p>
                                                <p style="color: #525252;font-size:15px;">Congratulations! You're now a Pulse Zero Trust Access user! Your domain can be accessed with below credentials:</p>
                                              </td>
                                              <td class="expander"></td>
                                            </tr>
                                          </table>
            
                                        </td>
                                      </tr>
                                    </table>
                                <!--end white intro-->
            
                                <!--grey panel-->
                                    <table class="row callout">
                                      <tr>
                                        <td class="wrapper last">
                                          <table style="padding: 30px 50px 0;" class="twelve columns">
                                            <tr>
                                              <td style="border: none;padding:0px 50px !important;" class="">
                                                <p style="background:#f6f6f6; padding: 30px 40px 55px; color: #525252;">
                                                    Username: <strong><span id="username">{tenant_data['username']}</span></strong><br>
                                                    Password: <strong><span id="password">{tenant_data['password']}</span></strong><br>
                                                    Pulse Zero Trust Access domain: <strong><span id="domain">{tenant_data['name']}</span></strong><br><br><br>
                                                    <a style="background-color:#2850FF; color: #fff; padding: 15px 25px;border-radius:5px;" href="https://{tenant_data['name']}/login/admin">Get Started</a>
                                                </p>
                                              </td>
                                            </tr>
                                          </table>
                                        </td>
                                      </tr>
                                    </table>
                                <!--end grey panel-->
                              </td>
                            </tr>
                          </table>
            
                        <!--SPACER-->
                          <table class="row">
                              <tr>
                                  <td style="height: 30px;"></td>
                              </tr>
                          </table>
                    <!--END BODY TABLE-->
            
                </body>
                </html>
            """
            msg['From'] = 'admin@perfzta.net'
            msg['To'] = target_email
            msg['Subject'] = "ZTA Tenant Credentials Alert"

            msg.attach(MIMEText(msg_body, 'html'))

            email = smtplib.SMTP(host=SMTP_HOST, port=SMTP_PORT)
            email.login(SMTP_USER, SMTP_PASSWORD)

            email.send_message(msg)
        except:
            result = False
            print(format_exc())
        finally:
            return result


class TenantAdmin(Session):
    """
        This class contains the actions of a Pule Zero Trust administrator
        who accesses and manages the tenant consoles
    """
    # Constructor
    def __init__(self, pzt_controller, password, username="admin"):
        try:
            self.pzt_controller = pzt_controller
            # self.base_url = f'https://{self.pzt_controller}'
            super(self.__class__, self).__init__()
            disable_warnings(InsecureRequestWarning)
            self.headers['Content-Type'] = 'application/x-www-form-urlencoded'
            self.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0;  Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
            # self.max_redirects = 10
            self.verify = False
            self.username = username
            self.password = password
            self.tenant_url = f'https://{self.pzt_controller}'
            if self.login_new() is False:
                raise Exception
            self.headers['Content-Type'] = 'application/json'
            print(f'Login to tenant {self.pzt_controller} is successful')
        except:
            print('Failed to login and create the admin object')

    def __del__(self):
        resp = self.get(url=f'https://{self.pzt_controller}/api/my-session/logout')
        print(resp.status_code)

    def login(self):
        result = True
        try:
            login_URL = self.tenant_url + '/login/admin'
            data = {"username": self.username, 
                    "password": self.password, 
                    "realm": 'Admin SignIn Policy',
                    "btnSubmit":"Submit"}

            r = self.post(url = login_URL)
            dssignin = self.cookies.get('DSSIGNIN')
            data = {"username": self.username,
                    "password": self.password, 
                    "realm": 'Admin SignIn Policy', 
                    "btnContinue":"Continue the session"}

            login_cgi = self.tenant_url + '/dana-na/auth/' +dssignin+ '/login.cgi'
            r = self.post(url= login_cgi, verify=False, data=data, allow_redirects=True)
            d = str(r.content)
            
            if 'Continue the session' in d:
                formdatastr = xsauth = None
                try:
                    #FormDataStr value
                    p = r'.*name="FormDataStr" value="(.*?)">'
                    x = re.findall( p, d)
                    formdatastr = x[0]
                except IndexError:
                    raise Exception
                try:
                    p = r'.*name="xsauth" value="(.*?)"'
                    x = re.findall( p, d)
                    xsauth = x[0]
                except IndexError:
                    raise Exception

                data = {"FormDataStr": formdatastr, "xsauth": xsauth, "btnContinue":"Continue the session"}

                #url = 
                login_cgi = self.tenant_url + '/dana-na/auth/' +dssignin+ '/login.cgi'
                r = self.post(url= login_cgi, verify=False, data=data)
            print(self.cookies)
        except:
            result = False
        finally:
            return result
        
    def login_new(self):
        result = True
        try:

            login_headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0;  Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0'
            }
            resp = self.get(f'https://{self.pzt_controller}/login/admin',
                            allow_redirects=True,
                            )
            if resp.status_code != 200:
                raise Exception

            # resp = self.get(resp.url)
            # if resp.status_code != 200:
            #     raise Exception
            login_url = resp.url.replace('welcome', 'login')
            sleep(2)
            # self.headers['Referer'] = resp.url
            login_info = {'username': self.username,
                          'password': self.password,
                          'realm': 'ZTA Admin Users',
                          'btnSubmit': 'Submit+Query'
                          }
            resp = self.post(url=login_url, data=login_info, allow_redirects=True)
            if resp.status_code != 200:
                raise Exception
            d = str(resp.content)
            if 'Continue the session' in d:
                formdatastr = xsauth = None
                try:
                    # FormDataStr value
                    p = r'.*name="FormDataStr" value="(.*?)">'
                    x = re.findall(p, d)
                    formdatastr = x[0]
                except IndexError:
                    raise Exception
                try:
                    p = r'.*name="xsauth" value="(.*?)"'
                    x = re.findall(p, d)
                    xsauth = x[0]
                except IndexError:
                    raise Exception
                confirm = {"FormDataStr": formdatastr,
                        "xsauth": xsauth,
                        "btnContinue": "Continue the session"}
                resp = self.post(url=login_url, data=confirm, allow_redirects=True)
                if resp.status_code != 200:
                    raise Exception
        except:
            result = False
            print(format_exc())
        finally:
            return result
        
    def map_view(self, entity='user'):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/analytics/ui/map_view',
                            params={'granularity': 'world',
                                    'overlaytype': entity})
            if resp.status_code != 200:
                raise Exception
            return resp.json()
        except:
            print(format_exc())
            return None

    def add_user_rule(self, rule_name, rule_type="username"):
        try:
            req_data = {
                "name": rule_name,
                "type": rule_type,
                "attribute": "is",
                "value": "*"
            }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/role-mapping-rules',
                             verify=False,
                             json=req_data)
            if resp.status_code not in (200, 409):
                raise Exception
            return True
        except:
            return False

    def del_user_rule(self, rule_name):
        try:
            rule = self.get_role_mapping_rule(rule_name)
            if rule is not None:
                resp = self.delete(url=f'https://{self.pzt_controller}/api/v1/policies/role-mapping-rules/{rule["id"]}',
                                   verify=False)
                if resp.status_code != 204:
                    raise Exception
            return True
        except:
            return False

    def get_role_mapping_rule(self, rule_name):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/role-mapping-rules',
                            verify=False)
            if resp.status_code != 200:
                raise Exception
            for item in resp.json()['items']:
                if item['name'] == rule_name:
                    return item
        except:
            return None

    def update_sign_in_policy(self, policy_name, server_name):
        try:
            result = True

            policy_data = self.get_sign_in_policy_details(policy_name)
            auth_server_id = self.get_auth_server(server_name)
            del policy_data['sign_in_config']['role_mapping_rules']
            policy_data['sign_in_config']['primary_auth_server_id'] = auth_server_id

            resp = self.put(url=f'https://{self.pzt_controller}/api/v1/policies/resources/{policy_data["id"]}',
                            json=policy_data)
            if resp.status_code != 200:
                raise Exception

        except:
            print(format_exc())
            result = False
        finally:
            return result

    def get_sign_in_policy_details(self, policy_name):
        try:
            result = None
            policy = self.get_sign_in_policy(policy_name)

            if policy is None:
                raise Exception
            policy_id = policy['id']

            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/resources/{policy_id}')
            print(resp.status_code, resp.json())
            if resp.status_code != 200:
                raise Exception

            result = resp.json()
        except:
            print(format_exc())
        finally:
            return result

    def get_sign_in_policy(self, pol_name):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/resources',
                            params={'type': 'sign_in'})
            if resp.status_code != 200:
                raise Exception
            for item in resp.json()['items']:
                if item['name'] == pol_name:
                    return item
        except:
            print(format_exc())
            return None

    def get_user_rule_group(self, group_name):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/user-rule-groups',
                            verify=False)
            if resp.status_code != 200:
                raise Exception
            for item in resp.json()['items']:
                if item['name'] == group_name:
                    return item
        except:
            return None

    def add_user_rule_group(self, pol_name, rule_name, group_name):
        try:
            pol_id = self.get_sign_in_policy(pol_name)['id']
            user_rule = self.get_role_mapping_rule(rule_name)

            req_data = {
                "name": group_name,
                "sign_in_policy_id": pol_id,
                "description": group_name.replace("_"," "),
                "rules": [{
                    "id": user_rule['id'],
                    "name": rule_name,
                    "type": user_rule['type'],
                    "operator": user_rule['attribute'],
                    "value": user_rule['value'],
                    "checked": True
                }]
            }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/user-rule-groups',
                             verify=False,
                             json=req_data)
            if resp.status_code != 200:
                raise Exception
            return True
        except:
            return False

    def del_user_rule_group(self, group_name):
        try:
            group = self.get_user_rule_group(group_name)
            if group is not None:
                resp = self.delete(url=f'https://{self.pzt_controller}/api/v1/policies/user-rule-groups/{group["id"]}',
                                   verify=False)
                if resp.status_code != 204:
                    raise Exception
            return True
        except:
            return False

    def get_resource_group(self, group_name):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/resource-groups',
                            verify=False)
            if resp.status_code != 200:
                raise Exception
            for item in resp.json()['items']:
                if item['name'] == group_name:
                    return item
        except:
            return None

    def get_resource(self, res_name):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/resources',
                            verify=False)
            if resp.status_code != 200:
                raise Exception
            for item in resp.json()['items']:
                if item['name'] == res_name:
                    return item
        except:
            return None

    def create_resource_group(self, res_grp_name, res_grp_type="application"):
        try:
            group_details = {
                "name": res_grp_name,
                "type": res_grp_type
            }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/resource-groups',
                             verify=False,
                             json=group_details)
            if resp.status_code != 200:
                raise Exception
            return True
        except:
            print(format_exc())
            return None

    def create_resource(self, res_grp_name, res_name, access_type="application"):
        try:

            group = self.get_resource_group(res_grp_name)
            if group is not None:

                app_config = {"name": res_name,
                              "access_type": access_type,
                              "resource": f"{res_name}.perftest.net",
                              "resource_type": "fqdn",
                              "bookmark_config": {"name": res_name,
                                                  "type": "web",
                                                  "description": f"{res_name}",
                                                  "launch_window": True,
                                                  "url": f"{res_name}.perftest.net",
                                                  "icon": "/admin/static/media/atlassian512.ef140e2e.svg"
                                                  }
                              }
                resource_data = {"name": res_name,
                                 "type": access_type,
                                 "description": f"{res_name}",
                                 "app_config": app_config
                                 }
                resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/resources',
                                 verify=False,
                                 json=resource_data)
                if resp.status_code != 200:
                    raise Exception
                res_id = resp.json()["id"]
                resp = self.put(
                    url=f'https://{self.pzt_controller}/api/v1/policies/resource-groups/{group["id"]}/resource/{res_id}',
                    verify=False)
                if resp.status_code != 204:
                    raise Exception
            return True
        except:
            print(format_exc())
            return None

    def get_device_policy(self):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups',
                            verify=False)
            if resp.status_code != 200:
                raise Exception
            if resp.json()['total'] > 0:
                return resp.json()['items'].pop()
        except:
            return None

    def create_secure_access_policy(self, user_group_name, res_name):
        try:
            user_group = self.get_user_rule_group(user_group_name)
            resource = self.get_resource(res_name)
            device_policy = self.get_device_policy()

            req_data = {
                "type": "application",
                "resource_type": "single",
                "user_rule_group_id": user_group['id'],
                "device_policy_id": device_policy['id'],
                "resource_id": resource['id'],
                "gateway_id": ""
            }

            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/secure-access-policies',
                             verify=False,
                             json=req_data)
        except:
            return None

    def create_gateway_in_controller(self, gw_name, gw_type, gw_loc):
        try:
            # to be removed
            print("Inside create gateway in controller")
            gateway_details = {"name": gw_name,
                               "orchestration": {"type": gw_type},
                               "location": {"city_id": gw_loc}
                               }
            resp = self.post(url=f'https://{self.pzt_controller}/api/gateways',
                             json=gateway_details)
            print("response code returned %s " %resp.status_code)
            if resp.status_code != 200:
                raise Exception
            # Return gateway id received from controller
            return resp.json()["id"]
        except RequestException as e:
            print(e)
            print("Subham comment")
            return None

    def __configure_gateway_details_in_controller(self, gw_data):
        try:
            locations = ['Bangalore', 'San Jose', 'Cambridge']
            gw_ext_fqdn = f"gateway{gw_id}.g.{self.pzt_controller}"
            gw_int_fqdn = f"int{gw_id}.{self.pzt_controller}"
            gw_mgt_fqdn = f"mgt{gw_id}.{self.pzt_controller}"
            gateway_details = {"service_account_id": None,
                               "appliance_config": {
                                   "admin_username": "admindb",
                                   "admin_password": "dana123",
                                   "company_name": "Pulse",
                                   "hostname": self.pzt_controller,
                                   "external_fqdn": gw_ext_fqdn,
                                   "external_gateway": f"10.165.1.1",
                                   "external_ip_address": f"10.165.1.{gw_id}",
                                   "external_subnet": "255.255.255.0",
                                   "external_vlan": "-1",
                                   "internal_fqdn": gw_int_fqdn,
                                   "internal_gateway": "10.165.2.1",
                                   "internal_ip_address": f"10.165.2.{gw_id}",
                                   "internal_subnet": "255.255.255.0",
                                   "internal_vlan": "-1",
                                   "management_domain_name": gw_mgt_fqdn,
                                   "management_gateway": "10.165.3.1",
                                   "management_ip_address": f"10.165.3.{gw_id}",
                                   "management_subnet": "255.255.255.0",
                                   "management_vlan": "-1",
                                   "primary_dns": "10.165.0.10",
                                   "private_domain_name": self.pzt_controller,
                                   "public_domain_name": self.pzt_controller,
                                   "secondary_dns": "",
                                   "location": choice(locations)
                               },
                               "deployment_config": None}
            resp = self.post(url=f'https://{self.pzt_controller}/api/gateways/{pzt_gw_id}/orchestration',
                                   verify=False,
                                   json=gateway_details)
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception

            # Return gateway id received from controller
            return resp.json()["appliance_id"]
        except:
            print(format_exc())
            return None

    def __fetch_gateway_reg_code(self, pzt_gw_id):
        try:
            resp = self.get(url=(f'https://{self.pzt_controller}/api/gateways/'
                                       f'{pzt_gw_id}/orchestration/init-config'))
            print(resp.status_code, resp.text)
            if resp.status_code != 200:
                raise Exception
            pre_reg_url = ""
            try:
                root = ET.fromstring(resp.text)
                elem = root[0].text
                if 'https' in elem:
                    pre_reg_url = elem.rstrip('\'').lstrip('\'')
            except ET.ParseError:
                for elem in resp.text.split(';'):
                    if 'vaConfigURL' in elem:
                        pre_reg_url = elem[elem.find('=') + 1:].rstrip('\'').lstrip('\'')

            resp = self.get(url=pre_reg_url, verify=False)
            if resp.status_code != 200:
                raise Exception

            reg_code = re.search(r'<registration-code-cleartext>(.*)</registration-code-cleartext>', resp.text).group(1)

            # Return gateway id received from controller
            return reg_code
        except:
            print(format_exc())
            return None

    def add_vsphere_gateway(self, gw_data):
        result = None
        try:
            gw_id = self.create_gateway_in_controller(gw_data['name'], 'vsphere', gw_data['location'])
            if gw_id is None:
                raise Exception

            gw_int_fqdn = f"int1.{self.pzt_controller}"
            mtls_domain = (self.pzt_controller[:self.pzt_controller.find('.')]+'.e' +
                           self.pzt_controller[self.pzt_controller.find('.'):])
            gateway_details = {"service_account_id": None,
                               "appliance_config": {
                                   "external_gateway": gw_data['ext_gw_ip'],
                                   "external_ip_address": gw_data['ext_ip'],
                                   "external_subnet": gw_data['ext_netmask'],
                                   "external_vlan": "-1",
                                   "internal_fqdn": gw_int_fqdn,
                                   "internal_gateway": gw_data['int_gw_ip'],
                                   "internal_ip_address": gw_data['int_ip'],
                                   "internal_subnet": gw_data['int_netmask'],
                                   "internal_vlan": "-1",
                                   "management_gateway": gw_data['mgmt_gw_ip'],
                                   "management_ip_address": gw_data['mgmt_ip'],
                                   "management_subnet": gw_data['mgmt_netmask'],
                                   "management_vlan": "-1",
                                   "primary_dns": gw_data['first_dns'],
                                   "private_domain_name": self.pzt_controller,
                                   "public_domain_name": mtls_domain,
                                   "secondary_dns": gw_data['sec_dns'],
                                   "location": gw_data['location']
                               },
                               "deployment_config": None}
            resp = self.post(url=f'https://{self.pzt_controller}/api/gateways/{gw_id}/orchestration',
                             json=gateway_details)
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception

            resp = self.get(url=(f'https://{self.pzt_controller}/api/gateways/'
                                 f'{gw_id}/orchestration/init-config'))
            print(resp.status_code, resp.text)
            if resp.status_code != 200:
                raise Exception

            result = resp.text
        except:
            print(format_exc())
        finally:
            return result

    def add_aws_gateway(self, gw_name, gw_type, city_code, pub_ip, pri_dns, sec_dns, dns_search_domain):
        result = None
        try:
            gw_id = self.create_gateway_in_controller(gw_name, gw_type, city_code)
            print("Gateway ID %s " % gw_id)
            print(f"Gateway name is {gw_name}")
            if gw_id is None:
                print("gateway ID is None")
                raise Exception

            gateway_details = {"service_account_id":None,
                                "appliance_config":{"public_ip_address":pub_ip,
                                                    "primary_dns":pri_dns,
                                                    "secondary_dns":sec_dns,
                                                    "dns_search_domain":dns_search_domain,
                                                    "private_domain_name":dns_search_domain},
                                                    "deployment_config":None}
            
            resp = self.post(url=f'https://{self.pzt_controller}/api/gateways/{gw_id}/orchestration',
                             json=gateway_details)
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception

            resp = self.get(url=(f'https://{self.pzt_controller}/api/gateways/'
                                 f'{gw_id}/orchestration/init-config'))
            print(resp.status_code, resp.text)
            file = open("aws-gw-config.txt", "w")
            file.write(resp.text)
            file.close()
            if resp.status_code != 200:
                raise Exception

            result = resp.text
        except:
            print(format_exc())
        finally:
            return result

    def create_aws_public_ips(self, stack_name, region, gatewayiptemplate, azureresourcegroup, azurenwsecgroup):
        try:
            print("Generating elastic IP address...")
            result = deploy_gateway_public_ips(stack_name, region, gatewayiptemplate)
            if not result:
                sys.exit(1)

            print('internal:' + result['internalip'] + ':' + result['internalid'])
            print('external:' + result['externalip'] + ':' + result['externalid'])
            internalip = result['internalip']
            #self.add_aws_gateway()
            azresult = update_az_network_security(azureresourcegroup, azurenwsecgroup, internalip)
            if not azresult:
                sys.exit(1)
            
        except:
            print(format_exc())

    def add_gateway(self, gid, gw_type, gw_loc):
        try:
            gateway_id = self.create_gateway_in_controller(gid, gw_type, gw_loc)
            if gateway_id is None:
                raise Exception

            if self.__configure_gateway_details_in_controller(gid, gateway_id) is None:
                raise Exception

            gw_reg_code = self.__fetch_gateway_reg_code(gateway_id)
            if gw_reg_code is None:
                raise Exception
            return {"id": gateway_id, "name": f"gateway{gid}", "registration_code": gw_reg_code}
        except:
            print(format_exc())
            return None

    def get_gateway_overview(self, name):
        result = None
        try:
            gid = self.get_gateway_id(name)
            print("GW ID", gid)
            resp = self.get(url=f'https://{self.pzt_controller}/api/analytics/apm/appstats?agg_type=AVG&bucket_size=hours&end_time_es=1585503715&gateway_ids={gid}&metric=ALL&start_time_es=1585417315')
            print(resp.json())
            if resp.status_code != 200:
                raise Exception
            result = resp.json()
        except:
            print(format_exc())
        finally:
            return result

    def get_gateway_id(self, name):
        result = None
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/gateways?limit=100&start=0')
            print(resp.json())
            if resp.status_code != 200:
                raise Exception
            result = resp.json()

            for item in resp.json():
                if item['name'] == name:
                    print(item["id"])
                    result = item["id"]
                    return item["id"]
        except:
            print(format_exc())
        finally:
            return result

    def delete_gateways(self):
        try:
            gateways = self.get_gateways()
            if gateways is not None:
                for gateway in gateways:
                    resp = self.delete(url=f'https://{self.pzt_controller}/api/gateways/{gateway["id"]}')
                    if resp.status_code != 204:
                        raise Exception
            return True
        except:
            print(format_exc())
            return False
    
    def verify_gw_logs(self, name):
        result = None
        try:
            gid = self.get_gateway_id(name)
            print("GW ID", gid)
            resp = self.get(url=f'https://{self.pzt_controller}/api/analytics/logs/search?columns=ALL&gateway_ids={gid}&limit=100&offset=0&order=desc&sort_by=timestamp')
            print(resp.json())
            if resp.status_code != 200:
                raise Exception
            result = resp.json()
            return True
        except:
            print(format_exc())
            return False

    def create_network_device_policy(self,device_policy_name,device_ploicy_description,rule_name,rule_description,ip,netmask,mode,label):
        result = None
        try:
            rule_id = self.create_network_device_policy_rule(rule_name,rule_description,ip,netmask,mode,label)
            policy_details = {"name":device_policy_name,
                              "description":device_ploicy_description
                               }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            resp1 = self.put(
                    url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups/{result}/rules/{rule_id}',
                    verify=False)
            if resp1.status_code != 204:
                    raise Exception
            return True
        except:
            print(format_exc())
            return False

    def create_network_device_policy_rule(self,rule_name,rule_description,ip,netmask,mode,label):
        result = None
        try:
            policy_details = {"name":rule_name,
                              "description":rule_description,
                               "network_config": {
                                   "ip_address":ip,
                                   "netmask":netmask,
                                   "mode":mode
                               },
                               "label":label,
                               "type":"network"}
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            if resp.json()["name"] != rule_name:
                    print("Network Rule Addition Failed: ",rule_name)
                    raise Exception
            
            print("Network Rule Addition Successful: ",resp.json()["name"])
            '''
            resp1 = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules')
            print(resp1.json())
            if resp1.status_code != 200:
                raise Exception
            '''
        except:
            print(format_exc())
            return False
        finally:
            return result

    def create_registry_device_policy(self,device_policy_name, device_ploicy_description, rule_name, rule_description, label, root_key, sub_key, key_type, key, key_value):
        result = None
        try:
            rule_id = self.create_registry_device_policy_rule(rule_name, rule_description, label, root_key, sub_key, key_type, key, key_value)
            policy_details = {"name":device_policy_name,
                              "description":device_ploicy_description
                               }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            resp1 = self.put(
                    url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups/{result}/rules/{rule_id}',
                    verify=False)
            if resp1.status_code != 204:
                    raise Exception
            return True
        except:
            print(format_exc())
            return False

    def create_registry_device_policy_rule(self, rule_name, rule_description, label, root_key, sub_key, key_type, key, key_value):
        result = None
        print("Starts")
        try:
            policy_details = {"name":rule_name,
                                "description":rule_description,
                                "label":label,
                                "type":"hostchecker",
                                "hostchecker_config":{"name":rule_name,
                                                    "type":"custom",
                                                    "custom_rule":{"platform":"windows",
                                                                    "type":"registry",
                                                                    "registry":{"root_key":root_key,
                                                                                "sub_key":sub_key,
                                                                                "key":key,
                                                                                "value":key_value,
                                                                                "is_64_bit":True,
                                                                                "remediate":True,
                                                                                "monitor":True,
                                                                                "type":key_type}}}}
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            if resp.json()["name"] != rule_name:
                    print("Regisry Rule Addition Failed: ",rule_name)
                    raise Exception
            
            print("Regisry Rule Addition Successful: ",resp.json()["name"])
            '''
            resp1 = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules')
            print(resp1.json())
            if resp1.status_code != 200:
                raise Exception
            '''
        except:
            print(format_exc())
            return False
        finally:
            return result

    def create_process_device_policy(self,device_policy_name, device_ploicy_description, rule_name, rule_description, label, platform, process_name, action, md5_checksum):
        result = None
        try:
            rule_id = self.create_process_device_policy_rule(rule_name, rule_description, label, platform, process_name, action, md5_checksum)
            policy_details = {"name":device_policy_name,
                              "description":device_ploicy_description
                               }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            resp1 = self.put(
                    url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups/{result}/rules/{rule_id}',
                    verify=False)
            if resp1.status_code != 204:
                    raise Exception
            return True
        except:
            print(format_exc())
            return False

    def create_process_device_policy_rule(self, rule_name, rule_description, label, platform, process_name, action, md5_checksum):
        result = None
        print("Starts")
        try:
            policy_details = {"name":rule_name,
                                "description":rule_description,
                                "label":label,
                                "type":"hostchecker",
                                "hostchecker_config":{"name":rule_name,
                                                    "type":"custom",
                                                    "custom_rule":{"platform":platform,
                                                                    "type":"process",
                                                                    "process":{"process_name":process_name,
                                                                                "monitor":"false",
                                                                                "action":action,
                                                                                "md5_checksum":md5_checksum}}}}
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            if resp.json()["name"] != rule_name:
                    print("Regisry Rule Addition Failed: ",rule_name)
                    raise Exception
            
            print("Regisry Rule Addition Successful: ",resp.json()["name"])
            '''
            resp1 = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules')
            print(resp1.json())
            if resp1.status_code != 200:
                raise Exception
            '''
        except:
            print(format_exc())
            return False
        finally:
            return result

    def create_os_device_policy(self,device_policy_name, device_ploicy_description, rule_name, rule_description, label, platform, os_name, os_version):
        result = None
        try:
            rule_id = self.create_os_device_policy_rule(rule_name, rule_description, label, platform, os_name, os_version)
            policy_details = {"name":device_policy_name,
                              "description":device_ploicy_description
                               }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            resp1 = self.put(
                    url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups/{result}/rules/{rule_id}',
                    verify=False)
            if resp1.status_code != 204:
                    raise Exception
            return True
        except:
            print(format_exc())
            return False

    def create_os_device_policy_rule(self, rule_name, rule_description, label, platform, os_name, os_version):
        result = None
        print("Starts")
        try:
            policy_details = {"name":rule_name,
                                "description":rule_description,
                                "label":label,
                                "type":"hostchecker",
                                "hostchecker_config":{"name":rule_name,
                                                    "type":"custom",
                                                    "custom_rule":{"platform":platform,
                                                                    "type":"os",
                                                                    "desktop_os_check":[{"os_version":os_name,
                                                                                        "service_pack_version":os_version}]}}}
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            if resp.json()["name"] != rule_name:
                    print("Regisry Rule Addition Failed: ",rule_name)
                    raise Exception
            
            print("Regisry Rule Addition Successful: ",resp.json()["name"])
            '''
            resp1 = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules')
            print(resp1.json())
            if resp1.status_code != 200:
                raise Exception
            '''
        except:
            print(format_exc())
            return False
        finally:
            return result

    def create_file_device_policy(self,device_policy_name, device_ploicy_description, rule_name, rule_description, label, platform, file_name, action,md5_checksum):
        result = None
        try:
            rule_id = self.create_file_device_policy_rule(rule_name, rule_description, label, platform, file_name, action,md5_checksum)
            policy_details = {"name":device_policy_name,
                              "description":device_ploicy_description
                               }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            resp1 = self.put(
                    url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/groups/{result}/rules/{rule_id}',
                    verify=False)
            if resp1.status_code != 204:
                    raise Exception
            return True
        except:
            print(format_exc())
            return False

    def create_syslog_server():
        result = None
        print("Starts")
        try:
            pass
        except:
            pass
    
    def add_client_auth():
        result = None
        print("Starts")
        try:
            pass
        except:
            pass
    
    def create_file_device_policy_rule(self, rule_name, rule_description, label, platform, file_name, action,md5_checksum):
        result = None
        print("Starts")
        try:
            policy_details = {"name":rule_name,
                                "description":rule_description,
                                "label":label,
                                "type":"hostchecker",
                                "hostchecker_config":{"name":rule_name,
                                                    "type":"custom",
                                                    "custom_rule":{"platform":platform,
                                                                    "type":"file",
                                                                    "file":{"file":file_name,
                                                                            "monitor":"false",
                                                                            "action":action,
                                                                            "md5_checksum":md5_checksum}}}}
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules',
                             json=policy_details)
            print(resp.json())
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            
            result = resp.json()["id"]
            if resp.json()["name"] != rule_name:
                    print("Regisry Rule Addition Failed: ",rule_name)
                    raise Exception
            
            print("Regisry Rule Addition Successful: ",resp.json()["name"])
            '''
            resp1 = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules')
            print(resp1.json())
            if resp1.status_code != 200:
                raise Exception
            '''
        except:
            print(format_exc())
            return False
        finally:
            return result

    def get_device_policy_rules(self):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/device-policies/rules')
            print(resp.json())
            if resp.status_code != 200:
                raise Exception
        except:
            print(format_exc())
            return False

    def add_saml_auth_server(self,name):
        result = None
        try:
            samlsp_config = {
                "name":name,
                "type":"SAML (Azure AD)",
                "samlsp_config":{
                    "metadata_config_type":"file",
                    "metadata_config_url":"",
                    "idp_type":"Azure AD",
                    "idp_metadata_xml":"PG1kOkVudGl0eURlc2NyaXB0b3IgeG1sbnM6bWQ9InVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDptZXRhZGF0YSIgY2FjaGVEdXJhdGlvbj0iUDk5OURUMEgwTTBTIiBlbnRpdHlJRD0iaHR0cHM6Ly9wZXJmMS5lLndpbGxvdy5wenQuZGV2LnBlcmZzZWMuY29tL2RhbmEtbmEvYXV0aC9zYW1sLWVuZHBvaW50LmNnaT9wPXNwMiI+PG1kOlNQU1NPRGVzY3JpcHRvciBwcm90b2NvbFN1cHBvcnRFbnVtZXJhdGlvbj0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnByb3RvY29sIj48bWQ6TmFtZUlERm9ybWF0PnVybjpvYXNpczpuYW1lczp0YzpTQU1MOjEuMTpuYW1laWQtZm9ybWF0OnVuc3BlY2lmaWVkPC9tZDpOYW1lSURGb3JtYXQ+PG1kOk5hbWVJREZvcm1hdD51cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoxLjE6bmFtZWlkLWZvcm1hdDplbWFpbEFkZHJlc3M8L21kOk5hbWVJREZvcm1hdD48bWQ6TmFtZUlERm9ybWF0PnVybjpvYXNpczpuYW1lczp0YzpTQU1MOjEuMTpuYW1laWQtZm9ybWF0Olg1MDlTdWJqZWN0TmFtZTwvbWQ6TmFtZUlERm9ybWF0PjxtZDpOYW1lSURGb3JtYXQ+dXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6MS4xOm5hbWVpZC1mb3JtYXQ6V2luZG93c0RvbWFpblF1YWxpZmllZE5hbWU8L21kOk5hbWVJREZvcm1hdD48bWQ6TmFtZUlERm9ybWF0PnVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpuYW1laWQtZm9ybWF0OmtlcmJlcm9zPC9tZDpOYW1lSURGb3JtYXQ+PG1kOk5hbWVJREZvcm1hdD51cm46b2FzaXM6bmFtZXM6dGM6U0FNTDoyLjA6bmFtZWlkLWZvcm1hdDplbnRpdHk8L21kOk5hbWVJREZvcm1hdD48bWQ6TmFtZUlERm9ybWF0PnVybjpvYXNpczpuYW1lczp0YzpTQU1MOjIuMDpuYW1laWQtZm9ybWF0OnRyYW5zaWVudDwvbWQ6TmFtZUlERm9ybWF0PjxtZDpBc3NlcnRpb25Db25zdW1lclNlcnZpY2UgQmluZGluZz0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmJpbmRpbmdzOkhUVFAtUE9TVCIgTG9jYXRpb249Imh0dHBzOi8vcGVyZjEuZS53aWxsb3cucHp0LmRldi5wZXJmc2VjLmNvbS9kYW5hLW5hL2F1dGgvc2FtbC1jb25zdW1lci5jZ2kiIGluZGV4PSIxIiBpc0RlZmF1bHQ9IjEiLz48L21kOlNQU1NPRGVzY3JpcHRvcj48L21kOkVudGl0eURlc2NyaXB0b3I+"
                    }}
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers',
                             json=samlsp_config)
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception  
            result = resp.text               
        except:
            print(format_exc())
        finally:
            return result

    def add_local_auth_server(self, auth_server_name, user_count=10):
        try:
            server_id = ''
            user_list = []
            for i in range(1, user_count + 1):
                user_list.append(
                    {"name": f"perfuser{i}", "full_name": f"Performance Test User {i}", "password": "dana123"})
            local_auth_server_details = {
                "name": auth_server_name,
                "type": "Local",
                "local_config": {"users": user_list}
            }
            resp = self.post(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers',
                             json=local_auth_server_details)
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers')
            if resp.status_code != 200:
                raise Exception
            for server in resp.json()['auth_servers']:
                if server['name'] == auth_server_name and \
                        server['type'] == 'Local':
                    server_id = server['id']
                    print(server_id)
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}/users')
            if resp.status_code != 200:
                raise Exception

            return True
        except:
            print(format_exc())
            return False

    def add_users_to_local_auth_server(self, server_name, user_list):
        try:
            server_id = ''
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers',
                            verify=False)
            if resp.status_code != 200:
                raise Exception
            print(resp.json())
            for server in resp.json()['auth_servers']:
                if server['name'] == server_name and \
                        server['type'] == 'Local':
                    server_id = server['id']
                    print(server_id)
            local_auth_server_details = {
                "name": server_name,
                "type": "Local",
                "local_config": {"users": user_list}
            }
            resp = self.put(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}',
                                  verify=False,
                                  json=local_auth_server_details)
            if resp.status_code != 200:
                raise Exception
            skip = '''
            user_data = {'users': user_list}
            resp = await self.post(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}/users',
                                   verify=False,
                                   json=user_data)
            print(resp.status_code)
            '''
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}/users',
                                  verify=False)
            print(resp.json())
            if resp.status_code != 200:
                raise Exception
            return True
        except:
            print(format_exc())
            return False

    def get_auth_server(self, server_name):
        try:
            result = None
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers')
            if resp.status_code != 200:
                raise Exception
            for server in resp.json()['auth_servers']:
                if server['name'] == server_name:
                    server_id = server['id']

            result = server_id
        except:
            print(format_exc())
        finally:
            return result

    def delete_auth_server(self, server_name):
        try:
            resp = self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers',
                                  verify=False)
            if resp.status_code != 200:
                raise Exception
            for server in resp.json()['auth_servers']:
                if server['name'] == server_name:
                    server_id = server['id']
                    resp = self.delete(
                        url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}',
                        verify=False)
                    if resp.status_code != 204:
                        raise Exception

            return True
        except:
            print(format_exc())
            return False


     
    def configure_user_policies_saml(self,server_name):
        try:
            server_id = self.get_auth_server(server_name)
            print(server_id)
            saml_auth_server_details = {
                "id":"21ff78e9-3fda-4b0c-86e7-af96dfa75680",
                "name":"User SignIn Policy",
                "description":"None",
                "type":"sign_in",
                "sign_in_config":{"url_pattern":"*/login/",
                "policy_type":"user",
                "primary_auth_server_id":server_id,
                "secondary_auth_server_id":"",
                "primary_authorization_server_id":"",
                "realm":"User SignIn Policy",
                "use_as_saml_idp":True}}
            resp = self.put(url=f'https://{self.pzt_controller}/api/v1/policies/resources/{server_id}',
                                  json=saml_auth_server_details)
            print(resp.status_code)
            print(resp.json())
            if resp.status_code != 200:
                raise Exception

            result = server_id
        except:
            print(format_exc())
        

class PztAdmin(AsyncClient):
    """
        This class contains the actions of a Pule Zero Trust administrator
        who accesses and manages the tenant consoles
    """
    # Constructor
    def __init__(self, pzt_controller):
        self.pzt_controller = pzt_controller
        # self.base_url = f'https://{self.pzt_controller}'
        super(self.__class__, self).__init__()

    async def __create_gateway_in_controller(self, gw_id, gw_infra="vsphere"):
        try:
            gateway_details = {"name": f"gateway{gw_id}",
                               "orchestration": {"type": gw_infra}
                               }
            resp = await self.post(url=f'https://{self.pzt_controller}/api/gateways',
                                   json=gateway_details,
                                   verify=False)
            if resp.status_code != 200:
                raise Exception
            # Return gateway id received from controller
            return resp.json()["id"]
        except:
            print(format_exc())
            return None

    async def __configure_gateway_details_in_controller(self, gw_id, pzt_gw_id):
        try:
            locations = ['Bangalore', 'San Jose', 'Cambridge']
            gw_ext_fqdn = f"gateway{gw_id}.g.{self.pzt_controller}"
            gw_int_fqdn = f"int{gw_id}.{self.pzt_controller}"
            gw_mgt_fqdn = f"mgt{gw_id}.{self.pzt_controller}"
            gateway_details = {"service_account_id": None,
                               "appliance_config": {
                                   "admin_username": "admindb",
                                   "admin_password": "dana123",
                                   "company_name": "Pulse",
                                   "hostname": self.pzt_controller,
                                   "external_fqdn": gw_ext_fqdn,
                                   "external_gateway": f"10.165.1.1",
                                   "external_ip_address": f"10.165.1.{gw_id}",
                                   "external_subnet": "255.255.255.0",
                                   "external_vlan": "-1",
                                   "internal_fqdn": gw_int_fqdn,
                                   "internal_gateway": "10.165.2.1",
                                   "internal_ip_address": f"10.165.2.{gw_id}",
                                   "internal_subnet": "255.255.255.0",
                                   "internal_vlan": "-1",
                                   "management_domain_name": gw_mgt_fqdn,
                                   "management_gateway": "10.165.3.1",
                                   "management_ip_address": f"10.165.3.{gw_id}",
                                   "management_subnet": "255.255.255.0",
                                   "management_vlan": "-1",
                                   "primary_dns": "10.165.0.10",
                                   "private_domain_name": self.pzt_controller,
                                   "public_domain_name": self.pzt_controller,
                                   "secondary_dns": "",
                                   "location": choice(locations)
                               },
                               "deployment_config": None}
            resp = await self.post(url=f'https://{self.pzt_controller}/api/gateways/{pzt_gw_id}/orchestration',
                                   verify=False,
                                   json=gateway_details)
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception

            # Return gateway id received from controller
            return resp.json()["appliance_id"]
        except:
            print(format_exc())
            return None

    async def __fetch_gateway_reg_code(self, pzt_gw_id):
        try:
            resp = await self.get(url=(f'https://{self.pzt_controller}/api/gateways/'
                                        f'{pzt_gw_id}/orchestration/init-config'),
                                  verify=False)
            if resp.status_code != 200:
                raise Exception
            pre_reg_url = ""
            try:
                root = ET.fromstring(resp.text)
                elem = root[0].text
                if 'https' in elem:
                    pre_reg_url = elem.rstrip('\'').lstrip('\'')
            except ET.ParseError:
                for elem in resp.text.split(';'):
                    if 'vaConfigURL' in elem:
                        pre_reg_url = elem[elem.find('=') + 1:].rstrip('\'').lstrip('\'')

            resp = await self.get(url=pre_reg_url, verify=False)
            if resp.status_code != 200:
                raise Exception

            reg_code = re.search(r'<registration-code-cleartext>(.*)</registration-code-cleartext>', resp.text).group(1)

            # Return gateway id received from controller
            return reg_code
        except:
            print(format_exc())
            return None

    async def add_gateway(self, gid, gw_type):
        try:
            gateway_id = await self.__create_gateway_in_controller(gid, gw_type)
            if gateway_id is None:
                raise Exception

            if await self.__configure_gateway_details_in_controller(gid, gateway_id) is None:
                raise Exception

            gw_reg_code = await self.__fetch_gateway_reg_code(gateway_id)
            if gw_reg_code is None:
                raise Exception
            return {"id": gateway_id, "name": f"gateway{gid}", "registration_code": gw_reg_code}
        except:
            print(format_exc())
            return None

    async def get_gateways(self):
        try:
            resp = await self.get(url=f'https://{self.pzt_controller}/api/gateways?limit=100&start=0')
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            return resp.json()
        except:
            print(format_exc())
            return None

    async def delete_gateways(self):
        try:
            gateways = await self.get_gateways()
            if gateways is not None:
                for gateway in gateways:
                    resp = await self.delete(url=f'https://{self.pzt_controller}/api/gateways/{gateway["id"]}')
                    if resp.status_code != 204:
                        raise Exception
            return True
        except:
            print(format_exc())
            return False

    async def add_local_auth_server(self, auth_server_name, user_count=10000):
        try:
            result = True
            server_id = ''
            user_list = []
            for i in range(1, user_count+1):
                user_list.append({"name": f"perfuser{i}",
                                  "full_name": f"Performance Test User {i}",
                                  "password": "dana123"})

            local_auth_server_details = {
                                            "name": auth_server_name,
                                            "type": "Local",
                                            "local_config": {"users": user_list}
                                        }
            resp = await self.post(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers',
                                   json=local_auth_server_details)
            if resp.status_code != 200:
                raise Exception

            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers')
            if resp.status_code != 200:
                raise Exception

            for server in resp.json()['auth_servers']:
                if server['name'] == auth_server_name and \
                        server['type'] == 'Local':
                    server_id = server['id']
                    print(server_id)
            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}/users')
            if resp.status_code != 200:
                raise Exception

        except:
            print(format_exc())
            result = False
        finally:
            return result

    async def add_users_to_local_auth_server(self, server_name, user_list):
        try:
            server_id = ''
            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers')
            if resp.status_code != 200:
                raise Exception
            print(resp.json())
            for server in resp.json()['auth_servers']:
                if server['name'] == server_name and \
                        server['type'] == 'Local':
                    server_id = server['id']
                    print(server_id)
            local_auth_server_details = {
                                            "name": server_name,
                                            "type": "Local",
                                            "local_config": {"users": user_list}
                                        }
            resp = await self.put(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}',
                                   verify=False,
                                   json=local_auth_server_details)
            if resp.status_code != 200:
                raise Exception
            skip = '''
            user_data = {'users': user_list}
            resp = await self.post(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}/users',
                                   verify=False,
                                   json=user_data)
            print(resp.status_code)
            '''
            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}/users',
                                  verify=False)
            print(resp.json())
            if resp.status_code != 200:
                raise Exception
            return True
        except:
            print(format_exc())
            return False

    async def delete_auth_server(self, server_name):
        try:
            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers',
                                  verify=False)
            if resp.status_code != 200:
                raise Exception
            for server in resp.json()['auth_servers']:
                if server['name'] == server_name:
                    server_id = server['id']
                    resp = await self.delete(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers/{server_id}',
                                             verify=False)
                    if resp.status_code != 204:
                        raise Exception

            return True
        except:
            print(format_exc())
            return False

    async def get_auth_server(self, server_name):
        try:
            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/auth-servers',
                                  verify=False)
            if resp.status_code != 200:
                raise Exception
            for server in resp.json()['auth_servers']:
                if server['name'] == server_name:
                    server_id = server['id']

            return server_id
        except:
            print(format_exc())
            return None

    async def get_user_rule_group(self, rule_group_name):
        try:
            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/user-rule-groups',
                                  verify=False)
            if resp.status_code != 200:
                raise Exception
            for rule in resp.json()['items']:
                if rule['name'] == rule_group_name:
                    return rule['id']
        except:
            print(format_exc())
            return None

    async def add_auth_policy(self, auth_pol_name, auth_pol_url, auth_serv_name, user_rule_group):
        try:
            auth_server_id = await self.get_auth_server(auth_serv_name)
            user_rule_group_id = await self.get_user_rule_group(user_rule_group)
            if auth_serv_name is None:
                raise Exception
            sign_in_config = {
                                "policy_type": "user",
                                "url_pattern": auth_pol_url,
                                "primary_auth_server_id": auth_server_id,
                                "realm": auth_pol_name
                            }
            user_resource_details = {
                                        "name": auth_pol_name,
                                        "type": "sign_in",
                                        "sign_in_config": sign_in_config
                                    }
            resp = await self.post(url=f'https://{self.pzt_controller}/api/v1/policies/resources',
                                   json=user_resource_details,
                                   verify=False)
            print(resp.status_code)
            if resp.status_code != 200:
                raise Exception
            user_resource_id = resp.json()['id']

            auth_policy_details = {"resource_id": user_resource_id,
                                   "resource_type": "single",
                                   "type": "sign_in",
                                   "user_rule_group_id": user_rule_group_id}
            resp = await self.post(url=f'https://{self.pzt_controller}/api/v1/policies/secure-access-policies',
                                   json=auth_policy_details,
                                   verify=False)
            if resp.status_code != 200:
                raise Exception

            return True
        except:
            print(format_exc())
            return False

    async def create_resource_group(self, res_grp_name, res_grp_type):
        try:
            group_details = {
                                "name": res_grp_name,
                                "type": res_grp_type
            }
            resp = await self.post(url=f'https://{self.pzt_controller}/api/v1/policies/resource-groups',
                                   json=group_details,
                                   verify=False)
            if resp.status_code != 200:
                raise Exception
            for rule in resp.json()['items']:
                if rule['name'] == res_grp_name:
                    return rule['id']
        except:
            print(format_exc())
            return None

    async def get_sign_in_policy(self, policy_name):
        try:
            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/resources?type=sign_in',
                                  verify=False)
            if resp.status_code != 200:
                raise Exception
            for policy in resp.json()['items']:
                if policy['name'] == policy_name:
                    return policy['id']
        except:
            print(format_exc())
            return None

    async def update_signin_policy(self, policy_name, auth_server, policy_id):
        try:
            if 'Enrollment' in policy_name:
                sign_in_url = "*/login/enroll"
            else:
                sign_in_url = "*/login"
            signin_config = {
                "url_pattern": sign_in_url,
                "policy_type": "user",
                "primary_auth_server_id": auth_server,
                "secondary_auth_server_id": None,
                "primary_authorization_server_id": None,
                "realm": "User SignIn Policy",
                "use_as_saml_idp": False
            }

            policy_config = {
                "name": policy_name,
                "description": "",
                "type": "sign_in",
                "id": policy_id,
                "sign_in_config": signin_config
            }

            resp = await self.put(url=f'https://{self.pzt_controller}/api/v1/policies/resources/{policy_id}',
                                  verify=False,
                                  json=policy_config)
            if resp.status_code != 200:
                raise Exception
        except:
            print(format_exc())
            return None

    async def create_resource(self, res_grp_name, res_name, access_type="application"):
        try:

            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/policies/resource-groups',
                                  verify=False)
            if resp.status_code != 200:
                raise Exception
            for grp in resp.json()['items']:
                if grp['name'] == res_grp_name:
                    grp_id = grp['id']

            app_config = {"name": res_name,
                          "access_type": access_type,
                          "resource": f"{res_name}.perftest.net",
                          "resource_type": "fqdn",
                          "bookmark_config": {"name": res_name,
                                              "type": "web",
                                              "description": f"test {res_name}",
                                              "launch_window": True,
                                              "url": f"{res_name}.perftest.net",
                                              "icon": "/admin/static/media/atlassian512.ef140e2e.svg"
                                              }
                          }
            resource_data = {"name": res_name,
                             "type": access_type,
                             "description": f"test {res_name}",
                             "app_config": app_config
                             }
            resp = await self.post(url=f'https://{self.pzt_controller}/api/v1/policies/resources',
                                   json=resource_data,
                                   verify=False)
            if resp.status_code != 200:
                raise Exception
            res_id = resp.json()["id"]
            resp = await self.put(url=f'https://{self.pzt_controller}/api/v1/policies/resource-groups/{grp_id}/resource/{res_id}',
                                  verify=False)
            if resp.status_code != 204:
                raise Exception

            for rule in resp.json()['items']:
                if rule['name'] == res_name:
                    return rule['id']
        except:
            print(format_exc())
            return None