__author__ = 'Vamsi Porala'
__email__ = 'vporala@pulsesecure.net'

try:
    import sys
    import os
    import logging
    from traceback import format_exc
    import json
    import yaml
    from time import sleep
    from datetime import date
except ImportError as err:
    print(f'Module import failed in {__name__} due to {err}')
    sys.exit(1)


class ConfigParser(object):
    """
    This class will parse the yaml input configuration file and return
    the json object
    """
    def __init__(self):
        pass

    @staticmethod
    def parse_config(config_file, file_loc="/root/zta/perftest/src/yaml/"):
        try:
            cfg_data = None
            with open(file_loc+config_file) as fd:
                cfg_data = yaml.load(fd, Loader=yaml.FullLoader)
                fd.close()
        except:
            pass
        finally:
            return cfg_data


class Generators:
    """
    This class contains the methods that generate the required dynamic variables
    for the test
    """

    def __init__(self):
        pass

    @staticmethod
    def generate_log_path(zta_domain, parent_dir="/root/zta/perftest/logs/"):
        result = None
        try:
            dir_path = os.path.join(parent_dir, str(date.today()))
            if not os.path.isdir(dir_path):
                os.mkdir(dir_path, 0o755)
            log_path = os.path.join(dir_path, zta_domain)
            # log_path = parent_dir+str(date.today())+'/'+zta_domain
            if not os.path.isdir(log_path):
                os.mkdir(log_path, 0o755)
                if os.path.isdir(log_path) is True:
                    result = log_path
            else:
                result = log_path
        except:
            print(format_exc())
        finally:
            return result

    @staticmethod
    def generate_logger(log_loc):
        result = None
        try:
            # print(logfile)
            fh_handler = logging.FileHandler(log_loc+'/TestLog', mode='w')
            format_msg = logging.Formatter(
                '[%(asctime)s %(levelname)s %(filename)s:%(lineno)s - %(funcName)20s()]  %(message)s')
            fh_handler.setFormatter(format_msg)
            # ch_handler = logging.StreamHandler()
            # ch_handler.setFormatter(format_msg)
            logger = logging.getLogger(__name__)
            logger.setLevel(logging.DEBUG)
            logger.addHandler(fh_handler)
            # logger.addHandler(ch_handler)
            result = logger
        except:
            print(format_exc())
        finally:
            return result
