__author__ = 'Vamsi Porala'
__email__ = 'vporala@pulsesecure.net'

try:
    import sys
    import os
    from httpx import AsyncClient
    from OpenSSL import crypto
    from traceback import format_exc
    from random import randint, choice
    from websocket import WebSocketApp
    from mohawk import Sender
    import _thread as thread
    import ssl
    import json
    from random import uniform, randint
    from datetime import datetime
    from base64 import b64decode, decodebytes
    from OpenSSL import crypto
    import ssl
except ImportError as err:
    print(f'Module import failed due to {err}')
    sys.exit(1)

TYPE_RSA = crypto.TYPE_RSA
TYPE_DSA = crypto.TYPE_DSA


class PztGateway(AsyncClient):
    """
        This class simulates the PZT gateway actions
    """

    # Constructor
    def __init__(self, pzt_controller):
        self.pzt_controller = pzt_controller
        super(self.__class__, self).__init__()

    @staticmethod
    def generate_key_pair(hash_type, key_length):
        try:
            pkey = crypto.PKey()
            pkey.generate_key(hash_type, key_length)
            return pkey
        except:
            return None

    @staticmethod
    def _generate_csr(key_obj, digest="sha", **name):
        try:
            req = crypto.X509Req()
            subj = req.get_subject()

            for (key, value) in name.items():
                setattr(subj, key, value)

            req.set_pubkey(key_obj)
            req.sign(key_obj, digest)
            return req
        except:
            return False

    def generate_csr(self, appliance_id):
        try:
            # Generate Key Pair
            key_pair = self.generate_key_pair(TYPE_RSA, 2048)
            csr = self._generate_csr(key_pair, digest="sha256", CN=appliance_id)
            return crypto.dump_certificate_request(crypto.FILETYPE_PEM, csr).decode()
        except:
            return None

    async def register_gateway(self, pzt_gw):
        try:
            gw_sw_version = choice(['9.1R4-%d' % randint(3800, 4500)])

            registration_info = {
                'registration_code': pzt_gw['registration_code'],
                'type': 'VPN',
                'model': 'PSA-5000-V',
                'serial_number': pzt_gw['id'],
                'appliance_version': gw_sw_version,
                'client_certificate_csr': self.generate_csr(pzt_gw['id'].replace('-', ''))
            }
            resp = await self.post(url=f'https://{self.pzt_controller}/api/gateways/register',
                                   verify=False,
                                   json=registration_info)
            if resp.status_code != 200:
                raise Exception
            gw_reg_info = resp.json()
            gw_reg_info["name"] = pzt_gw["name"]
            gw_reg_info["ca_chain"] = f'/root/pzt/gateways/{self.pzt_controller}/{pzt_gw["name"]}_ca'
            if os.path.isdir(f'/root/pzt/gateways/{self.pzt_controller}') is False:
                os.makedirs(f'/root/pzt/gateways/{self.pzt_controller}')
            json.dump(gw_reg_info, open(f'/root/pzt/gateways/{self.pzt_controller}/{pzt_gw["name"]}', 'w'))
            pzt_gw['registration_info'] = gw_reg_info
            with open(gw_reg_info['ca_chain'], 'w') as fd:
                fd.write(gw_reg_info['server_ca_cert_pem'])
                fd.close()
            return pzt_gw
        except:
            print(format_exc())
            return None

    async def verify_user_session(self, dsid):
        try:
            resp = await self.get(url=f'https://{self.pzt_controller}/api/v1/sessions/{dsid}',
                                  verify=False,
                                  params='')
            if resp.status_code == 200:
                return resp.json()
            elif resp.status_code == 404:
                return False
            else:
                raise Exception

        except:
            # print(format_exc())
            return False

    async def post_gw_stats(self, gname, gid, tid, rec_id):
        try:
            cpu = round(uniform(20, 95), 2)
            physical = round(uniform(20, 95), 2)
            swap = round(uniform(20, 95), 2)
            sessions = randint(1, 100)
            vpnsessions = randint(1, 100)
            interface_in = randint(10000000, 99999999)
            interface_out = randint(10000000, 99999999)
            external_in = randint(10000000, 99999999)
            external_out = randint(10000000, 99999999)
            file = randint(100, 1000)
            web = randint(100, 1000)
            sslconnection = randint(100, 1000)
            time_stamp = datetime.now().strftime('%s')

            gw_stat_data = {
                "records": [
                    {
                        "key": f"{rec_id}",
                        "value": {
                            "timestamp": f"{time_stamp}",
                            "version": "1",
                            "tenantid": tid,
                            "gatewayid": gid,
                            "gatewayname": f"{gname}.e.{self.pzt_controller}",
                            "type": "gatewaystats",
                            "message": {
                                "cpu": f"{cpu}",
                                "memory": {
                                    "physical": f"{physical}",
                                    "swap": f"{swap}"
                                },
                                "concurrentusers": {
                                    "sessions": f"{sessions}",
                                    "vpnsessions": f"{vpnsessions}"
                                },
                                "throughput": {
                                    "interface_in": f"{interface_in}",
                                    "interface_out": f"{interface_out}",
                                    "external_in": f"{external_in}",
                                    "external_out": f"{external_out}"
                                },
                                "hits": {
                                    "file": f"{file}",
                                    "web": f"{web}"
                                },
                                "sslconnection": f"{sslconnection}"
                            }
                        }
                    }
                ]
            }
            resp = await self.post(url=f'https://{self.pzt_controller}/api/analytics/gateways/topics/gateway_stats',
                                   verify=False,
                                   data=json.dumps(gw_stat_data),
                                   headers={"Content-Type": "application/vnd.kafka.json.v2+json",
                                            "Accept": "application/vnd.kafka.v2+json",
                                            })
            # if resp.status_code != 200:
            #     raise Exception

        except:
            print(format_exc())
            return False

    def gateway_websocket(self, url, creds, ca_cert):
        try:
            class GatewayWebSocket():
                def __init__(self, url, creds, ca_cert):
                    # To ignore cert check
                    ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
                    ssl_context.load_verify_locations(ca_cert)
                    ssl_context.check_hostname = False
                    # ssl_context.verify_mode = ssl.CERT_NONE

                    ssl_details = {"check_hostname": ssl_context.check_hostname,
                                   "cert_reqs": ssl_context.verify_mode}
                    sender = Sender({
                        'id': creds['id'],
                        'key': creds['key'],
                        'algorithm': 'sha256'
                    }, url, 'GET', always_hash_content=False)

                    self.ws = WebSocketApp(
                        url,
                        on_message=self.on_message,
                        on_error=self.on_error,
                        on_close=self.on_close,
                        header=['Authorization: %s' % sender.request_header])
                    self.ws.on_open = self.on_open
                    # self.ws.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE})
                    self.ws.run_forever(sslopt=ssl_details)

                @staticmethod
                def on_message(ws, message):
                    print('on message : ' + message)

                @staticmethod
                def on_error(ws, error):
                    print('on error : ' + str(error))

                @staticmethod
                def on_close(ws):
                    print(format_exc())
                    print('on close')

                @staticmethod
                def on_open(ws):
                    print('creating websocket connection')

            websock_connection = GatewayWebSocket(url, creds)
        except:
            return False


