__author__ = 'Vamsi Porala'
__email__ = 'vporala@pulsesecure.net'

try:
    import sys
    import os
    from requests import Session, cookies
    from traceback import format_exc
    from argparse import ArgumentParser
    from time import sleep
    from base64 import b64decode
    from OpenSSL import crypto
    from random import choice
    from urllib3 import disable_warnings
    from urllib3.exceptions import InsecureRequestWarning
except ImportError as err:
    print(f'Module import failed due to {err}')
    sys.exit(1)


class Client(Session):
    """
    This class covers the behavior of SDP client actions
    """
    # Constructor
    def __init__(self, kube_config_file):
        super(self.__class__, self).__init__()
        disable_warnings(InsecureRequestWarning)
        self.headers['Content-Type'] = 'application/json'

