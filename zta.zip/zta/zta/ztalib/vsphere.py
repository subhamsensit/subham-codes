__author__ = 'Vamsi Porala'
__email__ = 'vporala@pulsesecure.net'

try:
    import sys
    import os
    from httpx import AsyncClient
    from requests import Session
    from requests.exceptions import RequestException
    from requests import get
    from traceback import format_exc
    from random import choice
    import re
    import json
    import xml.etree.ElementTree as ET
    from urllib3 import disable_warnings
    from urllib3.exceptions import InsecureRequestWarning
    from kubernetes import client, config
    from urllib.parse import urlparse
    from time import sleep
    from email import message_from_string
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    import smtplib
    import base64
    from zipfile import ZipFile
    import shutil
    from pyVim.connect import SmartConnect, SmartConnectNoSSL, Disconnect
    from pyVmomi import vim
    from tools import tasks
except ImportError as err:
    print(f'Module import failed in {__name__} due to {err}')
    sys.exit(1)


class VSphere:
    """
    This class deals with deploying and registration of
    a vsphere gateway to tenant
    """
    def __init__(self, build, release='9.1'):
        self.portal_user = 'qa-auto'
        self.portal_user_passwd = '7Ez4IH24WhnMBCSy'
        self.build_portal = 'psbuild-portal.lab.psecure.net'
        disable_warnings(InsecureRequestWarning)
        self.admin = Session()
        self.admin.verify = False
        self.admin.auth = (self.portal_user, self.portal_user_passwd)
        self.build = build
        self.release = release
        self.zip_target_dir = f"/root/zta/perftest/vsphere/ovfs/build_{self.build}_ovf/"
        self.zipfile = f'/root/zta/perftest/vsphere/ovfs/build_{self.build}_ovf.zip'
        self.ovf_file = None
        self.vadmin = None
        self.vcontent = None

    def fetch_gateway_build_ovf(self):
        result = True
        try:
            if os.path.isfile(self.zipfile):
                if os.path.isdir(self.zip_target_dir):
                    return 'no_extract'
                else:
                    return 'extract'
            params = {
                'build': f'{self.build}.1',
                'buildType': 'prod',
                'dl': 'static',
                'buildCategory': 'int-rel',
                'productGroup': 'sa',
                'buildCounterRelease': self.release,
                'cmd': 'get',
                'what': 'speovf'
            }
            resp = self.admin.post(url=f'https://{self.build_portal}/index.cgi', data=params)
            if resp.status_code != 200:
                raise Exception
            match = re.search('HREF="(.*)" TYPE', resp.text)
            if match is None:
                raise Exception
            ovf_file = f'https://{self.build_portal}/{match.group(1)}'

            resp = self.admin.get(url=ovf_file, stream=True)
            if resp.status_code != 200:
                raise Exception
            with open(self.zipfile, 'wb') as fd:
                for chunk in resp.iter_content(chunk_size=1024):
                    if chunk:
                        fd.write(chunk)
                fd.close()
        except:
            print(format_exc())
            result = False
        finally:
            return result

    def extract_ovf_file(self):
        result = True
        try:
            with ZipFile(self.zipfile, 'r') as zip_fd:
                zip_fd.extractall(self.zip_target_dir)
        except:
            print(format_exc())
            result = False
        finally:
            return result

    def update_ovf_file(self, gw_config, ext_grp, int_grp, mgmt_grp):
        result = True
        try:
            prop = None
            skip = """
            name_spaces = {
                "xmlns": "http://schemas.dmtf.org/ovf/envelope/1",
                "xmlns:cim": "http://schemas.dmtf.org/wbem/wscim/1/common",
                # "xmlns:ovf": "http://schemas.dmtf.org/ovf/envelope/1",
                "xmlns:rasd": "http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_ResourceAllocationSettingData",
                "xmlns:vmw": "http://www.vmware.com/schema/ovf",
                "xmlns:vssd": "http://schemas.dmtf.org/wbem/wscim/1/cim-schema/2/CIM_VirtualSystemSettingData",
                "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance"
            }
            schema = r'{http://schemas.dmtf.org/ovf/envelope/1}'
            for prefix, uri in name_spaces.items():
                ET.register_namespace(prefix, uri)

            ovf_file = None
            for item in os.listdir(self.zip_target_dir):
                if '.ovf' in item:
                    ovf_file = item
            if ovf_file is None:
                raise Exception

            ovf_file = self.zip_target_dir+ovf_file
            if os.path.isfile(ovf_file):
                tree = ET.parse(ovf_file)
                if tree is not None:
                    root = tree.getroot()
                    for elem in root.iter():
                        if 'Property' in elem.tag:
                            prop = elem
                    if prop is not None:
                        print(gw_config)
                        prop.attrib[f'{schema}value'] = gw_config
                        tree.write(ovf_file, xml_declaration=True, encoding='utf-8')
                """
            ovf_file = None
            for item in os.listdir(self.zip_target_dir):
                if '.ovf' in item:
                    ovf_file = item
            if ovf_file is None:
                raise Exception
            self.ovf_file = self.zip_target_dir + ovf_file
            shutil.copyfile(self.ovf_file, f'{self.ovf_file}.orig')
            with open(self.ovf_file, 'r') as fd:
                temp = fd.read()
                fd.close()

            if temp:
                if re.search('ovf:value=.* ovf:userConfigurable', temp) is not None:
                    temp = re.sub('ovf:value=.* ovf:userConfigurable', f'ovf:value="{gw_config}" ovf:userConfigurable', temp)
                else:
                    print('Pattern not found')
                if 'InternalNetwork' in temp:
                    temp = temp.replace('InternalNetwork', int_grp)
                if 'ExternalNetwork' in temp:
                    temp = temp.replace('ExternalNetwork', ext_grp)
                if 'ManagementNetwork' in temp:
                    temp = temp.replace('ManagementNetwork', mgmt_grp)
                with open(self.ovf_file, 'w') as fd:
                    fd.write(temp)
                    fd.close()

        except:
            result = False
        finally:
            return result

    def get_ovf_descriptor(self):
        """
        Read in the OVF descriptor.
        """
        result = None
        try:
            if self.ovf_file is not None:
                if os.path.exists(self.ovf_file):
                    with open(self.ovf_file, 'r') as f:
                        result = f.read()
                        f.close()
        except:
            print(format_exc())
        finally:
            return result

    @staticmethod
    def get_obj_in_list(obj_name, obj_list):
        """
        Gets an object out of a list (obj_list) whos name matches obj_name.
        """
        result = None
        try:
            for o in obj_list:
                if o.name == obj_name:
                    result = o
        except:
            print(format_exc())
        finally:
            return result

    def login_to_vcenter(self, server, user, password, port=443):
        try:
            self.vadmin = SmartConnectNoSSL(host=server,
                                            user=user,
                                            pwd=password,
                                            port=port)
            if self.vadmin is None:
                raise Exception
            self.vcontent = self.vadmin.RetrieveContent()

        except:
            print(format_exc())

    skip = """
    def mydec(self):

        def mydec_func(func):
            if not self.vcontent:
                self.vcontent = self.vadmin.RetrieveContent()
            return func()

        return mydec_func
    """

    # @mydec
    def get_vms(self):
        vm_list = []
        vm_view = None
        try:
            if self.vcontent is not None:
                vms = self.vcontent.viewManager.CreateContainerView(self.vcontent.rootFolder,
                                                                    [vim.VirtualMachine], True)
                vm_list = [vm for vm in vms.view]
        except:
            print(format_exc())
        finally:
            return vm_list

    @staticmethod
    def get_vm_nics(vm):
        nics = []
        try:
            for device in vm.config.hardware.device:
                if isinstance(device, vim.vm.device.VirtualEthernetCard):
                    nicspec = vim.vm.device.VirtualDeviceSpec()
                    nicspec.device = device
                    nics.append(nicspec)
        except:
            print(format_exc())
        finally:
            return nics

    @staticmethod
    def get_host_port_groups(host):
        port_groups = None
        try:
            port_groups = host.config.network.portgroup
        except:
            print(format_exc())
        finally:
            return port_groups

    def get_hosts(self):
        host_list = []
        try:
            hosts = self.vcontent.viewManager.CreateContainerView(self.vcontent.rootFolder,
                                                                  [vim.HostSystem], True)
            host_list = [host for host in hosts.view]
        except:
            print(format_exc())
        finally:
            return host_list

    def get_obj(self, vim_type, name):
        obj = None
        container = self.vcontent.viewManager.CreateContainerView(
            self.vcontent.rootFolder, vim_type, True)
        for c in container.view:
            if c.name == name:
                obj = c
                break
        return obj

    def change_nic_port_group(self, vm_obj, nic_number, port_group):
        result = True
        try:
            nic_prefix_label = 'Network adapter '
            nic_label = nic_prefix_label + str(nic_number)
            for device in vm_obj.config.hardware.device:
                if isinstance(device, vim.vm.device.VirtualEthernetCard) \
                        and device.deviceInfo.label == nic_label:
                    nicspec = vim.vm.device.VirtualDeviceSpec()
                    nicspec.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit
                    nicspec.device = device
                    nicspec.device.wakeOnLanEnabled = True
                    nicspec.device.backing = vim.vm.device.VirtualEthernetCard.NetworkBackingInfo()
                    nicspec.device.backing.network = self.get_obj([vim.Network], port_group)
                    nicspec.device.backing.deviceName = port_group
                    nicspec.device.connectable = vim.vm.device.VirtualDevice.ConnectInfo()
                    nicspec.device.connectable.startConnected = True
                    nicspec.device.connectable.allowGuestControl = True
                    dev_changes = [nicspec]
                    spec = vim.vm.ConfigSpec()
                    spec.deviceChange = dev_changes
                    task = vm_obj.ReconfigVM_Task(spec=spec)
                    tasks.wait_for_tasks(self.vadmin, [task])
                    break
        except:
            result = False
            print(format_exc())
        finally:
            return result
