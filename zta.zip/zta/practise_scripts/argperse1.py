import argparse

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="argperse practise")
    parser.add_argument("--gw_name", help ="give gw name",\
                        choices=["aws","azure","gcp"],required=True)
    parser.add_argument("--zone", help= "zone")
   # parser.add_argument("operation", help="operation number")
    args=parser.parse_args()

    print(args.gw_name)
    print(f'The gateway name is  {args.gw_name}  and zone {args.zone}')