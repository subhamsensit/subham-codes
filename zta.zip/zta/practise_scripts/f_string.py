'''
This is to practise f string
'''