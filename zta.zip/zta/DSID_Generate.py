import requests
import logging
import re


SSLCertverify = False
apiHeaders = {"Content-type": "application/json", "Accept": "application/json"}

class DSID_Generate(object):

    def login(self, url, username, password):
        self.tenant_url = url
        return_dict = {'status': 0}
        global user_session, dsid
        login_URL = self.tenant_url + '/login/admin'
        data = {"username": username, "password": password, "realm": 'ZTA Admin Users', "btnSubmit": "Submit"}
        user_session = requests.session()
        #user_session.get(login_URL)
        r = user_session.get(url=login_URL, verify=False)
        dssignin = user_session.cookies.get('DSSIGNIN')

        data = {"username": username, "password": password, "realm": 'ZTA Admin Users',
                "btnContinue": "Continue the session"}

        login_cgi = url + '/dana-na/auth/' + dssignin + '/login.cgi'
        print(login_cgi)
        r = user_session.post(url=login_cgi, verify=False, data=data    )

        logging.debug("login status code: ", + r.status_code)
        logging.debug("Login_data: ", r.content)

        d = str(r.content)

        if 'Continue the session' in d:
            formdatastr = xsauth = None
            try:
                # FormDataStr value
                p = r'.*name="FormDataStr" value="(.*?)">'
                x = re.findall(p, d)
                formdatastr = x[0]
            except IndexError:
                print('Error: unable to get FormDataStr value')

            try:
                p = r'.*name="xsauth" value="(.*?)"'
                x = re.findall(p, d)
                xsauth = x[0]
            except IndexError:
                print('Error: unable to get xsauth value')

            data = {"FormDataStr": formdatastr, "xsauth": xsauth, "btnContinue": "Continue the session"}

            login_cgi = url + '/dana-na/auth/' + dssignin + '/login.cgi'
            r = user_session.post(url=login_cgi, verify=False, data=data, allow_redirects=True)
        dsid = user_session.cookies.get('DSID')
        if dsid is None:
            raise Exception('LoginError: Unable to get DSID cookie')
            # self.cookie = dsid
        self.session = user_session
        return dsid

# pzt_inst = DSID_Generate()
# pzt_inst.login(host_name[0:-1], user, password)

