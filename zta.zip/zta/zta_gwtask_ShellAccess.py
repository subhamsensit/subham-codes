import json
import requests


def create_gateway_task():

    dsid_value = '64050c31c0d044861f921e7b1268d05b'
    tenant = 'tenant1.navy-blue.pzt.dev.perfsec.com'
    rdc_code = "249418-MJOCMLPP-HP"
    gateway_id = "edab84e349e444678bbd85cf757e9142"

    
    urx = 'https://{}/api/gateways/tasks'.format(tenant)

    headers = {
        "Content-Type": "application/json"
     }

    cookies = {
        "DSID": dsid_value
    }

    task_json = {
        "target": {"id": gateway_id, "type": "appliance"},
        "type": "system.operations.appliance.debug.connect_shell_access",
        "params": {
            "remote_debug_code": rdc_code,
            "server": "service.pulsesecure.net"
        }
    }


    task_status = {"status": "success"}

    j = json.dumps(task_json)

    r = requests.post(urx, j, headers=headers, cookies=cookies)
    print (r.status_code)
    assert r.status_code == 200
    return r.json()

print (create_gateway_task())